import {insideStickerTarget} from './collection.js';
// The same drag lifecycle handles fingers, mouse, cancellation and a viewport change.
export function mountStickerDrag({stage,source,target,onPlace}){
  let drag=null,settling=false,disposed=false,keyboardCarrying=false,animation=null;
  const visual=active=>{source.setAttribute('aria-grabbed',String(active));stage.classList.toggle('is-dragging-sticker',active);if(!active)target.classList.remove('drop-ready')};
  const point=(x,y)=>{const rect=stage.getBoundingClientRect();return {left:x-rect.left,top:y-rect.top}};
  const position=(ghost,x,y)=>{const p=point(x,y);ghost.style.left=p.left+'px';ghost.style.top=p.top+'px'};
  const releaseCapture=id=>{if(source.hasPointerCapture(id))source.releasePointerCapture(id)};
  async function finish(event,cancelled=false){
    if(!drag||event&&event.pointerId!==drag.id)return;
    const current=drag;drag=null;settling=true;source.disabled=true;releaseCapture(current.id);
    const accepted=!cancelled&&insideStickerTarget({x:event.clientX,y:event.clientY},target.getBoundingClientRect());
    const box=(accepted?target:source).getBoundingClientRect(),end=point(box.left+box.width/2,box.top+box.height/2),reduced=matchMedia('(prefers-reduced-motion:reduce)').matches;
    target.classList.toggle('drop-ready',accepted);
    try{
      if(!reduced&&current.ghost.animate){
        animation=current.ghost.animate([{left:current.ghost.style.left,top:current.ghost.style.top,transform:'translate(-50%,-50%) rotate(-4deg) scale(1)'},{left:end.left+'px',top:end.top+'px',transform:`translate(-50%,-50%) rotate(0deg) scale(${accepted?1:.86})`}],{duration:accepted?190:260,easing:'cubic-bezier(.2,.8,.25,1)',fill:'forwards'});
        await animation.finished;
      }
      if(disposed)return;
      if(accepted)await onPlace();
    }catch(error){if(!disposed&&error.name!=='AbortError')console.error('贴纸拖动失败',error)}
    finally{animation=null;current.ghost.remove();if(!disposed){settling=false;source.disabled=false;visual(false);}}
  }
  source.onpointerdown=e=>{
    if(disposed||settling||drag||e.button!==0||e.isPrimary===false)return;
    e.preventDefault();keyboardCarrying=false;source.setPointerCapture(e.pointerId);
    const box=target.getBoundingClientRect(),ghost=document.createElement('img');ghost.className='dragging-sticker';ghost.src=source.querySelector('img').src;ghost.alt='';ghost.style.width=box.width+'px';ghost.style.height=box.height+'px';stage.append(ghost);
    drag={id:e.pointerId,ghost};visual(true);position(ghost,e.clientX,e.clientY);
  };
  source.onpointermove=e=>{if(!drag||e.pointerId!==drag.id)return;position(drag.ghost,e.clientX,e.clientY);target.classList.toggle('drop-ready',insideStickerTarget({x:e.clientX,y:e.clientY},target.getBoundingClientRect()))};
  source.onpointerup=e=>finish(e);source.onpointercancel=e=>finish(e,true);source.onlostpointercapture=e=>finish(e,true);
  source.onkeydown=e=>{if((e.key===' '||e.key==='Enter')&&!settling){e.preventDefault();keyboardCarrying=true;visual(true);target.focus()}};
  const escape=e=>{if(e.key==='Escape'){keyboardCarrying=false;if(drag)finish(null,true);else visual(false)}};
  target.onclick=async()=>{if(!keyboardCarrying||settling||disposed)return;keyboardCarrying=false;settling=true;try{await onPlace()}finally{settling=false;if(!disposed)visual(false)}};
  const cancel=()=>{if(drag)finish(null,true);keyboardCarrying=false};stage.addEventListener('appviewportchange',cancel);stage.addEventListener('keydown',escape);
  return ()=>{disposed=true;animation?.cancel();if(drag){const current=drag;drag=null;current.ghost.remove();releaseCapture(current.id)}visual(false);stage.removeEventListener('appviewportchange',cancel);stage.removeEventListener('keydown',escape);source.onpointerdown=source.onpointermove=source.onpointerup=source.onpointercancel=source.onlostpointercapture=source.onkeydown=target.onclick=null;};
}
