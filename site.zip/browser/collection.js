import {latestRewards} from './core.js';
export function collectionPage(works,themeID){
 const latest=new Map(latestRewards(works).map(a=>[a.course.id,a]));
 return Array.from({length:5},(_,i)=>{const courseID=`${themeID}_${String(i+1).padStart(2,'0')}`,work=latest.get(courseID);return {courseID,work,placed:!!work?.collectedAt};});
}
export function insideStickerTarget(point,rect){return point.x>=rect.left&&point.x<=rect.right&&point.y>=rect.top&&point.y<=rect.bottom;}
const cache=new Map();
// Alpha-based cut line follows the child's actual silhouette, not a rectangle.
export function stickerImages(art){
 const key=art.id+':'+art.thumbnail;
 if(!cache.has(key))cache.set(key,buildSticker(art.thumbnail));return cache.get(key);
}
async function buildSticker(url){
 const image=new Image();image.src=url;await image.decode();const size=560,padding=28,contentSize=size-padding*2;
 const canvas=()=>{const c=document.createElement('canvas');c.width=c.height=size;return c;};
 const silhouette=radius=>{
  const c=canvas(),x=c.getContext('2d');
  for(let i=0;i<64;i++){const a=i*Math.PI/32;x.drawImage(image,padding+Math.cos(a)*radius,padding+Math.sin(a)*radius,contentSize,contentSize);}
  x.drawImage(image,padding,padding,contentSize,contentSize);x.globalCompositeOperation='source-in';x.fillStyle='white';x.fillRect(0,0,size,size);x.globalCompositeOperation='source-over';return c;
 };
 const base=silhouette(24),inset=silhouette(17),c=base.getContext('2d');
 const mask=inset.getContext('2d').getImageData(0,0,size,size).data,edges=new Map(),stride=2,n=size/stride;
 const filled=(x,y)=>x>=0&&y>=0&&x<n&&y<n&&mask[((y*stride)*size+x*stride)*4+3]>120;
 const edge=(x,y,a,b)=>edges.set(x+','+y,[a,b]);
 for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(filled(x,y)){
  if(!filled(x,y-1))edge(x,y,x+1,y);
  if(!filled(x+1,y))edge(x+1,y,x+1,y+1);
  if(!filled(x,y+1))edge(x+1,y+1,x,y+1);
  if(!filled(x-1,y))edge(x,y+1,x,y);
 }
 c.strokeStyle='#51485c';c.lineWidth=5;c.setLineDash([18,12]);c.lineJoin='round';c.lineCap='round';
 while(edges.size){
  const start=edges.keys().next().value;let key=start,points=[];
  while(edges.has(key)){const p=key.split(',').map(Number);points.push(p.map(v=>v*stride));const next=edges.get(key);edges.delete(key);key=next.join(',');if(key===start)break;}
  if(points.length<10)continue;
  points=points.filter((_,i)=>i%2===0);const last=points.at(-1),first=points[0];c.beginPath();c.moveTo((last[0]+first[0])/2,(last[1]+first[1])/2);
  for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];c.quadraticCurveTo(a[0],a[1],(a[0]+b[0])/2,(a[1]+b[1])/2);}c.closePath();c.stroke();
 }
 c.setLineDash([]);c.drawImage(image,padding,padding,contentSize,contentSize);
 const guide=silhouette(33),g=guide.getContext('2d');g.globalCompositeOperation='source-in';g.fillStyle='#f52d70';g.fillRect(0,0,size,size);g.globalCompositeOperation='destination-out';g.drawImage(silhouette(21),0,0);
 return {sticker:base.toDataURL('image/png'),guide:guide.toDataURL('image/png')};
}
