// Turn only a paper half. The sidebar, mascot and book spine stay planted.
export function turnBookPage(stage,previousScreen,direction,{reduced=false}={}){
  if(reduced||!previousScreen||typeof previousScreen.animate!=='function')return {finished:Promise.resolve(),cancel(){}};
  const width=stage.clientWidth,height=stage.clientHeight;
  const leaf=document.createElement('div');leaf.className=`book-turn-leaf book-turn-${direction>0?'next':'prev'}`;leaf.setAttribute('aria-hidden','true');
  const snapshot=previousScreen.cloneNode(true);snapshot.classList.add('book-turn-snapshot');
  for(const element of snapshot.querySelectorAll('button,.collection-nav,.collection-side,.collection-mascot,.collection-drag-guide'))if(!element.matches('.reward-slot'))element.remove();
  snapshot.querySelectorAll('[id]').forEach(element=>element.removeAttribute('id'));
  snapshot.style.width=width+'px';snapshot.style.height=height+'px';
  snapshot.style.left=-(direction>0?width*.6:width*.345)+'px';snapshot.style.top=-(height*.09)+'px';
  leaf.append(snapshot);stage.append(leaf);
  const angle=direction>0?-165:165;
  const animation=leaf.animate([{transform:'perspective(1000px) rotateY(0deg)',opacity:1},{transform:`perspective(1000px) rotateY(${angle*.5}deg)`,opacity:1,offset:.55},{transform:`perspective(1000px) rotateY(${angle}deg)`,opacity:0}],{duration:680,easing:'cubic-bezier(.35,.05,.2,1)',fill:'forwards'});
  const cancel=()=>{animation.cancel();leaf.remove();};
  const resized=()=>cancel();stage.addEventListener('appviewportchange',resized);
  const finished=animation.finished.catch(()=>{}).finally(()=>{stage.removeEventListener('appviewportchange',resized);leaf.remove();});
  return {finished,cancel};
}
