export class DrawingVoice {
  constructor(audio){this.audio=audio;this.token=0;this.buffers=new Map();this.pending=new Map();}
  async loadManifest(){
    if(!this.manifestPromise)this.manifestPromise=fetch(new URL('./drawing-voice-manifest.json',import.meta.url)).then(response=>{if(!response.ok)throw Error('引导配音配置未加载');return response.json();}).catch(error=>{this.manifestPromise=null;throw error;});
    return this.manifestPromise;
  }
  async buffer(context,name){
    if(this.buffers.has(name))return this.buffers.get(name);
    if(!this.pending.has(name))this.pending.set(name,fetch(new URL('../声音/绘画引导/'+name,import.meta.url)).then(response=>{if(!response.ok)throw Error('引导配音未加载');return response.arrayBuffer();}).then(bytes=>context.decodeAudioData(bytes)).then(buffer=>{this.pending.delete(name);this.buffers.set(name,buffer);while(this.buffers.size>12)this.buffers.delete(this.buffers.keys().next().value);return buffer;}).catch(error=>{this.pending.delete(name);throw error;}));
    return this.pending.get(name);
  }
  warm(course){
    if(!this.audio.enabled)return;
    Promise.all([this.audio.prepare(),this.loadManifest()]).then(([context,manifest])=>{
      const entry=manifest[course.id];if(!context||!entry)return;
      for(const name of new Set([entry.intro,...Object.values(entry.steps)]))this.buffer(context,name).catch(()=>{});
    }).catch(()=>{});
  }
  stop(){
    this.token++;if(this.source){try{this.source.stop();}catch{}this.source=null;}
    this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);
  }
  async speak(course,step,{intro=false}={}){
    this.stop();if(!this.audio.enabled)return;const token=this.token;
    try{
      const [context,manifest]=await Promise.all([this.audio.prepare(),this.loadManifest()]);
      const entry=manifest[course.id],name=intro?entry?.intro:entry?.steps[step.id];if(!context||!name)return;
      const buffer=await this.buffer(context,name);if(token!==this.token||!this.audio.enabled)return;
      if(context.state!=='running')await context.resume();if(token!==this.token||context.state!=='running')return;
      const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;gain.gain.value=.85;
      source.connect(gain).connect(context.destination);this.source=source;this.audio.music.volume=this.audio.musicVolume*.2;
      source.onended=()=>{source.disconnect();gain.disconnect();if(token===this.token){this.source=null;this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);}};source.start();
    }catch(error){console.warn('绘画引导配音加载失败',error);}
  }
}
