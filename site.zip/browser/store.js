import {validateCourse} from './core.js';
export class ArtworkStore {
  async open(){
    this.db=await new Promise((resolve,reject)=>{const request=indexedDB.open('baby-draw-v8',1);request.onupgradeneeded=()=>{request.result.createObjectStore('artworks',{keyPath:'id'});};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(Error('请关闭其他试画窗口后重试'));});
    return this;
  }
  async save(art,retry=true){
    const snapshot=structuredClone(art);
    return new Promise((resolve,reject)=>{
      const tx=this.db.transaction('artworks','readwrite'),store=tx.objectStore('artworks');
      const read=store.get(snapshot.id);read.onsuccess=()=>{if(!read.result||read.result.revision<=snapshot.revision)store.put(snapshot);};
      tx.oncomplete=()=>resolve(snapshot);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('保存被中断'));
    }).catch(async error=>{
      if(retry&&['InvalidStateError','UnknownError','AbortError'].includes(error?.name)){this.db?.close();await this.open();return this.save(snapshot,false);}
      throw error;
    });
  }
  async remove(id){
    return new Promise((resolve,reject)=>{
      const tx=this.db.transaction('artworks','readwrite');tx.objectStore('artworks').delete(id);
      tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('清理未完成画作失败'));
    });
  }
  async load(){
    const rows=await new Promise((resolve,reject)=>{const request=this.db.transaction('artworks','readonly').objectStore('artworks').getAll();request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
    const valid=[],invalid=[];
    for(const row of rows){try{if(row.schemaVersion!==1||!Number.isInteger(row.currentIndex)||row.currentIndex<0||row.currentIndex>=row.course.steps.length)throw Error();validateCourse(row.course);valid.push(row);}catch{invalid.push(row.id);}}
    return {valid,invalid};
  }
  async collect(id){
    return new Promise((resolve,reject)=>{
      const tx=this.db.transaction('artworks','readwrite'),store=tx.objectStore('artworks'),read=store.get(id);let result;
      read.onsuccess=()=>{const art=read.result;if(!art?.completed){tx.abort();return;}if(!art.collectedAt){art.collectedAt=Date.now();art.revision++;store.put(art);}result=art;};
      tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('贴纸还没贴好'));
    });
  }
}
