const STORAGE_KEY='baby-draw-sound-enabled';
const MUSIC_ENABLED_KEY='baby-draw-music-enabled';
const MUSIC_VOLUME_KEY='baby-draw-music-volume';

export class AudioService {
  constructor(){
    this.enabled=localStorage.getItem(STORAGE_KEY)!=='false';this.context=null;this.lastPlayed=new Map();this.stroke=null;this.strokeToken=0;this.samplePlayers=new Map();
    this.musicEnabled=localStorage.getItem(MUSIC_ENABLED_KEY)!=='false';const savedMusicVolume=Number(localStorage.getItem(MUSIC_VOLUME_KEY)??.28);this.musicVolume=Number.isFinite(savedMusicVolume)?Math.min(1,Math.max(0,savedMusicVolume)):.28;
    this.music=new Audio(new URL('../声音/音乐背景.MP3',import.meta.url));this.music.loop=true;this.music.preload='auto';this.music.volume=this.musicVolume;
    this.music.addEventListener('ended',()=>{if(this.musicEnabled){this.music.currentTime=0;this.music.play().catch(()=>{});}});this.music.load();
    this.samples={
      tap:{url:new URL('../声音/按钮点击声.mp3',import.meta.url),volume:.52},
      theme:{url:new URL('../声音/tab滑动.mp3',import.meta.url),volume:.52},
      course:{url:new URL('../声音/卡片.MP3',import.meta.url),volume:.52},
      tool:{url:new URL('../声音/工具(1).MP3',import.meta.url),volume:.52},
      step:{url:new URL('../声音/步骤完成.MP3',import.meta.url),volume:.52},
      complete:{url:new URL('../声音/整幅完成.MP3',import.meta.url),volume:.52},
      page:{url:new URL('../声音/翻页.MP3',import.meta.url),volume:.52}
    };
    for(const sample of Object.values(this.samples)){const audio=new Audio(sample.url);audio.preload='auto';audio.load();sample.audio=audio;}
    this.roleFiles={cat:'陆地/小猫声.MP3',dog:'陆地/狗叫声.MP3',horse:'陆地/马叫声.MP3',frog:'陆地/青蛙叫.MP3',mouse:'陆地/老鼠叫.MP3'};
    Object.assign(this.roleFiles,{
      ocean_01:'海洋/金鱼.MP3',ocean_02:'海洋/鲸鱼.MP3',ocean_03:'海洋/鲨鱼.MP3',ocean_04:'海洋/章鱼.MP3',ocean_05:'海洋/螃蟹.MP3',
      sky_01:'天空/小鸟.MP3',sky_02:'天空/飞机.MP3',sky_03:'天空/热气球.MP3',sky_04:'天空/火箭.MP3',sky_05:'天空/彩虹.MP3',
      dolls_01:'娃娃/洋娃娃.MP3',dolls_02:'娃娃/熊娃娃.MP3',dolls_03:'娃娃/兔子.MP3',dolls_04:'娃娃/雪人.MP3',dolls_05:'娃娃/木偶.MP3',
      cars_01:'汽车/小汽车.MP3',cars_02:'汽车/公交车.MP3',cars_03:'汽车/工程车.MP3',cars_04:'汽车/挖掘机.MP3',cars_05:'汽车/火车.MP3',
      forest_01:'森林/兔子.MP3',forest_02:'森林/松鼠.MP3',forest_03:'森林/狐狸.MP3',forest_04:'森林/熊.MP3',forest_05:'森林/刺猬.MP3',
      insects_01:'昆虫/蝴蝶.MP3',insects_02:'昆虫/昆虫2.MP3',insects_03:'昆虫/昆虫3.MP3',insects_04:'昆虫/昆虫4.MP3',insects_05:'昆虫/昆虫5.MP3',
      vegetables_01:'蔬菜/胡萝卜.MP3',vegetables_02:'蔬菜/西红柿.MP3',vegetables_03:'蔬菜/南瓜.MP3',vegetables_04:'蔬菜/西兰花.MP3',vegetables_05:'蔬菜/茄子.MP3',
      castles_01:'城堡/城堡1.MP3',castles_02:'城堡/城堡2.MP3',castles_03:'城堡/城堡3.MP3',castles_04:'城堡/城堡4.MP3',castles_05:'城堡/城堡5.MP3',
      instruments_01:'乐器/吉他.MP3',instruments_02:'乐器/钢琴.MP3',instruments_03:'乐器/架子鼓).MP3',instruments_05:'乐器/大提琴.MP3',
      princesses_01:'公主/公主1.MP3',princesses_02:'公主/公主2.MP3',princesses_03:'公主/公主3.MP3',princesses_04:'公主/公主4.MP3',princesses_05:'公主/公主5(1).MP3'
    });
    this.roleBuffers=new Map();this.roleLoading=new Map();
  }
  roleKey(course){return this.roleFiles[course.id]?course.id:course.themeID==='land'?course.animal:null;}
  unlockEffects(theme='land'){
    if(!this.enabled)return;
    this.prepare().then(context=>{if(context){this.loadStepBuffer(context);for(const animal of Object.keys(this.roleFiles).filter(key=>theme==='land'?!key.includes('_'):key.startsWith(theme+'_')))this.loadRoleBuffer(context,animal).catch(()=>{});}}).catch(()=>{});
  }
  loadStepBuffer(context){
    if(this.stepBuffer)return Promise.resolve(this.stepBuffer);
    if(!this.stepLoading)this.stepLoading=fetch(this.samples.step.url).then(response=>{
      if(!response.ok)throw Error('步骤音频加载失败');return response.arrayBuffer();
    }).then(bytes=>context.decodeAudioData(bytes)).then(buffer=>{this.stepBuffer=buffer;return buffer;}).catch(error=>{this.stepLoading=null;throw error;});
    // Preloading may fail on an interrupted mobile connection; allow the next touch to retry.
    this.stepLoading.catch(()=>{});return this.stepLoading;
  }
  async playStep(){
    try{
      const context=await this.prepare();if(!context)throw Error('音频通道不可用');
      const buffer=await this.loadStepBuffer(context);if(!this.enabled)return;
      if(context.state!=='running')await context.resume();
      if(context.state!=='running')throw Error('音频通道暂停');
      this.stepSource?.stop();
      const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;gain.gain.value=this.samples.step.volume;
      source.connect(gain).connect(context.destination);this.stepSource=source;
      source.onended=()=>{if(this.stepSource===source)this.stepSource=null;source.disconnect();gain.disconnect();};source.start();
    }catch{if(this.enabled)this.playSample('step');}
  }
  async playCelebration(){
    if(!this.enabled)return;
    const audio=this.samples.complete.audio;
    await new Promise(resolve=>{
      let timer;const finish=()=>{clearTimeout(timer);audio.removeEventListener('ended',finish);audio.removeEventListener('error',finish);resolve();};
      audio.addEventListener('ended',finish);audio.addEventListener('error',finish);
      timer=setTimeout(finish,3000);
      this.playSample('complete');
    });
  }
  stopRole(){
    this.roleToken=(this.roleToken??0)+1;clearTimeout(this.roleTimer);
    this.roleDone?.();this.roleDone=null;
    for(const source of this.roleSources??[]){try{source.stop();}catch{}}
    this.roleSources=[];this.roleDucking=false;this.music.volume=this.musicVolume;
  }
  loadRoleBuffer(context,animal){
    if(this.roleBuffers.has(animal))return Promise.resolve(this.roleBuffers.get(animal));
    if(!this.roleLoading.has(animal)){
      const loading=fetch(new URL('../声音/板块声音/'+this.roleFiles[animal],import.meta.url)).then(response=>{if(!response.ok)throw Error('角色音频加载失败');return response.arrayBuffer();}).then(bytes=>context.decodeAudioData(bytes)).then(buffer=>{this.roleBuffers.set(animal,buffer);return buffer;}).catch(error=>{this.roleLoading.delete(animal);throw error;});
      this.roleLoading.set(animal,loading);
    }
    return this.roleLoading.get(animal);
  }
  async playRole(animal,duration=4.8){
    this.stopRole();if(!this.enabled)return;
    if(!this.roleFiles[animal])return;const token=this.roleToken,deadline=performance.now()+duration*1000;
    try{
      const context=await this.prepare();if(!context)return;
      const buffer=await this.loadRoleBuffer(context,animal);if(!this.enabled||token!==this.roleToken)return;
      if(context.state!=='running')await context.resume();if(token!==this.roleToken||context.state!=='running')return;
      const remaining=(deadline-performance.now())/1000;if(remaining<=0)return;
      this.roleDucking=true;this.music.volume=this.musicVolume*.35;
      const start=context.currentTime;
      for(let offset=0;offset<remaining-.08;offset+=buffer.duration+.3){
        const length=Math.min(buffer.duration,remaining-offset),at=start+offset;
        const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;
        gain.gain.setValueAtTime(.0001,at);gain.gain.linearRampToValueAtTime(.52,at+Math.min(.015,length/3));
        gain.gain.setValueAtTime(.52,at+Math.max(length-.045,length/2));gain.gain.linearRampToValueAtTime(.0001,at+length);
        source.connect(gain).connect(context.destination);this.roleSources.push(source);
        source.onended=()=>{source.disconnect();gain.disconnect();};source.start(at,0,length);
      }
      await new Promise(resolve=>{this.roleDone=resolve;this.roleTimer=setTimeout(()=>{if(token===this.roleToken)this.stopRole();},remaining*1000);});
    }catch(error){if(token===this.roleToken)this.stopRole();console.warn('角色音频播放失败',animal,error);}
  }
  startMusic(){if(this.openingActive||!this.musicEnabled||!this.music.paused)return;if(this.music.ended)this.music.currentTime=0;this.music.play().catch(()=>{});}
  setMusicEnabled(value){
    this.musicEnabled=!!value;localStorage.setItem(MUSIC_ENABLED_KEY,String(this.musicEnabled));
    if(this.musicEnabled)this.startMusic();else this.music.pause();
  }
  setMusicVolume(value){this.musicVolume=Math.min(1,Math.max(0,Number(value)));this.music.volume=this.musicVolume*(this.roleDucking?.35:1);localStorage.setItem(MUSIC_VOLUME_KEY,String(this.musicVolume));}
  setEnabled(value){this.enabled=!!value;localStorage.setItem(STORAGE_KEY,String(this.enabled));if(!this.enabled){this.stopRole();this.stepSource?.stop();this.stepSource=null;this.stopStroke();for(const audio of this.samplePlayers.values()){clearTimeout(audio.stopTimer);audio.pause();audio.currentTime=0;}this.samplePlayers.clear();this.context?.suspend().catch(()=>{});}else this.unlockEffects();}
  playSample(name){
    const sample=this.samples[name];if(!sample||!this.enabled)return false;
    const previous=this.samplePlayers.get(name);if(previous){clearTimeout(previous.stopTimer);previous.pause();previous.currentTime=0;}
    const audio=sample.audio;clearTimeout(audio.stopTimer);audio.pause();audio.volume=sample.volume;audio.currentTime=sample.startAt??0;this.samplePlayers.set(name,audio);
    const finish=()=>{clearTimeout(audio.stopTimer);if(this.samplePlayers.get(name)===audio)this.samplePlayers.delete(name);};
    audio.onended=finish;if(sample.maxDuration)audio.stopTimer=setTimeout(()=>{audio.pause();audio.currentTime=0;finish();},sample.maxDuration*1000);
    audio.play().catch(finish);return true;
  }
  async prepare(){
    if(!this.enabled)return null;
    const AudioContext=window.AudioContext||window.webkitAudioContext;
    if(!AudioContext)return null;
    this.context??=new AudioContext();
    if(this.context.state!=='running'&&this.context.state!=='closed')await this.context.resume().catch(()=>{});
    return this.context;
  }
  tone(context,{at=context.currentTime,frequency,endFrequency=frequency,duration=.08,volume=.04,type='sine',attack=.008,filter=0}){
    const oscillator=context.createOscillator(),gain=context.createGain();let output=gain;
    volume=Math.min(volume*3,.12);
    oscillator.type=type;oscillator.frequency.setValueAtTime(frequency,at);
    if(endFrequency!==frequency)oscillator.frequency.exponentialRampToValueAtTime(endFrequency,at+duration);
    gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(volume,at+attack);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
    oscillator.connect(gain);
    if(filter){const node=context.createBiquadFilter();node.type='lowpass';node.frequency.value=filter;gain.connect(node);output=node;}
    output.connect(context.destination);oscillator.start(at);oscillator.stop(at+duration+.02);
  }
  noise(context,{at=context.currentTime,duration=.1,volume=.02,frequency=1800,type='bandpass',attack=.006,q=.7}){
    volume=Math.min(volume*3.2,.08);
    const length=Math.max(1,Math.ceil(context.sampleRate*duration)),buffer=context.createBuffer(1,length,context.sampleRate),data=buffer.getChannelData(0);
    for(let i=0;i<length;i++)data[i]=(Math.random()*2-1)*(1-i/length);
    const source=context.createBufferSource(),filter=context.createBiquadFilter(),gain=context.createGain();source.buffer=buffer;filter.type=type;filter.frequency.value=frequency;filter.Q.value=q;
    gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(volume,at+attack);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
    source.connect(filter).connect(gain).connect(context.destination);source.start(at);source.stop(at+duration+.01);
  }
  bell(context,{at=context.currentTime,frequency=523,duration=.22,volume=.035}){
    this.tone(context,{at,frequency,endFrequency:frequency*.992,duration,volume,type:'sine',attack:.009,filter:2600});
    this.tone(context,{at:at+.006,frequency:frequency*2,endFrequency:frequency*1.97,duration:duration*.58,volume:volume*.12,type:'sine',attack:.007,filter:3200});
  }
  bubble(context,{at=context.currentTime,frequency=440,endFrequency=720,duration=.13,volume=.035}){
    this.tone(context,{at,frequency,endFrequency,duration,volume,type:'sine',attack:.012,filter:1700});
    this.tone(context,{at:at+.008,frequency:frequency*1.5,endFrequency:endFrequency*1.3,duration:duration*.64,volume:volume*.09,type:'sine',attack:.009,filter:2200});
  }
  async startStroke(){
    if(this.stroke||!this.enabled)return;
    const token=++this.strokeToken,context=await this.prepare();if(!context||token!==this.strokeToken)return;
    const length=Math.ceil(context.sampleRate*.32),buffer=context.createBuffer(1,length,context.sampleRate),data=buffer.getChannelData(0);
    let last=0;for(let i=0;i<length;i++){const white=Math.random()*2-1;last=last*.82+white*.18;data[i]=last*(.72+Math.sin(i*.047)*.1);}
    const source=context.createBufferSource(),high=context.createBiquadFilter(),low=context.createBiquadFilter(),gain=context.createGain(),at=context.currentTime;
    source.buffer=buffer;source.loop=true;high.type='highpass';high.frequency.value=420;low.type='lowpass';low.frequency.value=2800;low.Q.value=.45;
    gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.014,at+.08);
    source.connect(high).connect(low).connect(gain).connect(context.destination);source.start(at);this.stroke={source,gain};
  }
  stopStroke(){
    this.strokeToken++;if(!this.stroke)return;const {source,gain}=this.stroke,at=this.context?.currentTime??0;this.stroke=null;
    gain.gain.cancelScheduledValues(at);gain.gain.setValueAtTime(Math.max(.0001,gain.gain.value),at);gain.gain.exponentialRampToValueAtTime(.0001,at+.08);
    try{source.stop(at+.09);}catch{}
  }
  setDrawing(active){if(active)this.startStroke();else this.stopStroke();}
  async play(name){
    const now=performance.now(),minimumGap=35;
    if(now-(this.lastPlayed.get(name)??0)<minimumGap)return;
    this.lastPlayed.set(name,now);
    if(name==='step'){if(this.enabled)await this.playStep();return;}
    if(this.playSample(name))return;
    const context=await this.prepare();if(!context)return;const at=context.currentTime+.006;
    switch(name){
      case 'tap':
        this.tone(context,{at,frequency:520,endFrequency:230,duration:.13,volume:.025,type:'sine',attack:.006,filter:1150});
        this.bubble(context,{at:at+.105,frequency:205,endFrequency:315,duration:.19,volume:.022});break;
      case 'theme':
        this.noise(context,{at,duration:.6,volume:.011,frequency:980,type:'bandpass',attack:.12,q:.3});
        this.noise(context,{at:at+.05,duration:.5,volume:.004,frequency:2250,type:'highpass',attack:.17,q:.2});
        this.tone(context,{at:at+.015,frequency:210,endFrequency:390,duration:.57,volume:.004,type:'sine',attack:.13,filter:650});break;
      case 'course':
        this.bell(context,{at,frequency:659,duration:.39,volume:.023});
        this.bell(context,{at:at+.115,frequency:988,duration:.275,volume:.016});
        this.noise(context,{at:at+.02,duration:.2,volume:.0018,frequency:4400,type:'highpass',attack:.04});break;
      case 'tool':
        this.tone(context,{at,frequency:430,endFrequency:145,duration:.23,volume:.03,type:'sine',attack:.006,filter:720});
        this.tone(context,{at:at+.2,frequency:180,endFrequency:360,duration:.17,volume:.023,type:'sine',attack:.007,filter:820});
        this.tone(context,{at:at+.345,frequency:345,endFrequency:245,duration:.145,volume:.012,type:'sine',attack:.006,filter:760});break;
      case 'color':
        [[659,0,.22,.013],[880,.075,.23,.013],[1175,.15,.25,.011],[1568,.235,.255,.008]].forEach(([frequency,delay,duration,volume])=>this.bell(context,{at:at+delay,frequency,duration,volume}));
        this.noise(context,{at:at+.17,duration:.31,volume:.002,frequency:4800,type:'highpass',attack:.05});break;
      case 'step':
        this.bell(context,{at,frequency:523,duration:.32,volume:.024});
        this.bell(context,{at:at+.245,frequency:784,duration:.445,volume:.031});
        this.tone(context,{at:at+.275,frequency:392,endFrequency:523,duration:.36,volume:.006,type:'sine',attack:.04,filter:900});break;
      case 'complete':
        [[523,0,.29,.019],[659,.14,.3,.02],[784,.28,.32,.021],[659,.43,.28,.017],[1047,.59,.59,.029]].forEach(([frequency,delay,duration,volume])=>this.bell(context,{at:at+delay,frequency,duration,volume}));
        this.bubble(context,{at:at+.64,frequency:330,endFrequency:660,duration:.49,volume:.009});
        this.noise(context,{at:at+.55,duration:.61,volume:.0023,frequency:3900,type:'highpass',attack:.11});break;
      case 'sticker':
        this.noise(context,{at,duration:.5,volume:.015,frequency:1850,type:'bandpass',attack:.025,q:1.5});
        this.noise(context,{at:at+.055,duration:.4,volume:.005,frequency:4200,type:'highpass',attack:.015});
        this.tone(context,{at:at+.47,frequency:250,endFrequency:105,duration:.18,volume:.029,type:'sine',attack:.005,filter:540});
        this.bubble(context,{at:at+.57,frequency:160,endFrequency:220,duration:.23,volume:.016});break;
      case 'page':
        this.noise(context,{at,duration:.7,volume:.016,frequency:760,type:'bandpass',attack:.13,q:.5});
        this.noise(context,{at:at+.09,duration:.53,volume:.008,frequency:1900,type:'bandpass',attack:.055,q:.85});
        this.noise(context,{at:at+.31,duration:.28,volume:.0045,frequency:3100,type:'highpass',attack:.025,q:.4});break;
      default:this.tone(context,{at,frequency:430,endFrequency:260,duration:.065,volume:.03,type:'triangle'});
    }
  }
}
