// Eleven unique themes on a ring: selected in slot 5, five neighbours each side.
export function mountThemeCarousel(strip,initial,onSelect){
  const tabs=[...strip.children],order=tabs.map(t=>Number(t.dataset.theme));
  const byTheme=new Map(tabs.map(t=>[Number(t.dataset.theme),t]));
  const count=order.length,middle=Math.floor(count/2),mod=n=>(n%count+count)%count;
  let selected=initial,grab=null,dragged=false,disposed=false,wheelTimer,wheelDelta=0;
  function select(theme,animate=true){
    if(disposed||!byTheme.has(theme))return;
    selected=theme;const current=order.indexOf(theme),fragment=document.createDocumentFragment();
    for(let slot=0;slot<count;slot++){
      const tab=byTheme.get(order[mod(current+slot-middle)]),old=Number(tab.dataset.slot);
      // Wrapped neighbours move across the hidden seam, never across the row.
      tab.style.transition=(!animate||slot===middle||Math.abs(old-slot)>middle)?'none':'';
      tab.style.setProperty('--slot',slot);tab.dataset.slot=slot;
      tab.setAttribute('aria-selected',String(slot===middle));tab.tabIndex=slot===middle?0:-1;
      fragment.append(tab);
    }
    strip.append(fragment);strip.style.setProperty('--drag-x','0px');
    const active=byTheme.get(theme);active.classList.remove('theme-tab-enter');
    if(animate){void active.offsetWidth;active.classList.add('theme-tab-enter');active.addEventListener('animationend',()=>active.classList.remove('theme-tab-enter'),{once:true});}
    requestAnimationFrame(()=>{if(!disposed)tabs.forEach(t=>t.style.transition='');});
  }
  function move(steps){
    select(order[mod(order.indexOf(selected)+steps)]);onSelect(selected);
  }
  for(const tab of tabs){
    tab.onclick=()=>{if(!dragged){select(Number(tab.dataset.theme));onSelect(selected);}};
    tab.onkeydown=e=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
      e.preventDefault();
      if(e.key==='Home'||e.key==='End'){select(order[e.key==='Home'?0:count-1]);onSelect(selected);}
      else move(e.key==='ArrowLeft'?-1:1);
      byTheme.get(selected).focus({preventScroll:true});
    };
  }
  strip.onpointerdown=e=>{if(grab||e.button!==0||e.isPrimary===false)return;dragged=false;grab={x:e.clientX,id:e.pointerId};};
  strip.onpointermove=e=>{
    if(!grab||e.pointerId!==grab.id)return;
    const dx=e.clientX-grab.x,stride=strip.clientWidth*.071;
    if(Math.abs(dx)>5){
      dragged=true;if(!strip.hasPointerCapture(e.pointerId))strip.setPointerCapture(e.pointerId);
      strip.style.setProperty('--drag-x',Math.max(-stride*.8,Math.min(stride*.8,dx))+'px');
    }
  };
  strip.onpointerup=e=>{
    if(!grab||e.pointerId!==grab.id)return;
    const dx=e.clientX-grab.x;grab=null;
    if(strip.hasPointerCapture(e.pointerId))strip.releasePointerCapture(e.pointerId);
    strip.style.setProperty('--drag-x','0px');
    if(dragged&&Math.abs(dx)>12)move(-Math.sign(dx)*Math.max(1,Math.round(Math.abs(dx)/(strip.clientWidth*.071))));
  };
  const cancel=()=>{const id=grab?.id;grab=null;dragged=false;strip.style.setProperty('--drag-x','0px');if(id!==undefined&&strip.hasPointerCapture(id))strip.releasePointerCapture(id)};
  strip.onpointercancel=e=>{if(grab?.id===e.pointerId)cancel()};strip.onlostpointercapture=e=>{if(grab?.id===e.pointerId)cancel()};
  const stage=strip.closest('#stage');stage?.addEventListener('appviewportchange',cancel);
  const wheel=e=>{
    e.preventDefault();wheelDelta+=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;
    clearTimeout(wheelTimer);wheelTimer=setTimeout(()=>{if(Math.abs(wheelDelta)>4)move(Math.sign(wheelDelta));wheelDelta=0;},100);
  };
  strip.addEventListener('wheel',wheel,{passive:false});select(initial,false);
  return {select,dispose(){disposed=true;clearTimeout(wheelTimer);strip.removeEventListener('wheel',wheel);stage?.removeEventListener('appviewportchange',cancel);cancel();}};
}
