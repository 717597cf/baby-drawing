import {mountStickerDrag} from './sticker-drag.js?v=phone-fit-1';
import {mountViewport} from './viewport.js?v=phone-fit-1';
import {playOpening} from './opening.js?v=visible-intro-16';
import {THEMES,THEME_IDS,TOOLS,validateCourse,createArtwork,stepOf,appendMark,previous,next,canNext,latestRewards,touch} from './core.js';
import {ArtworkStore} from './store.js?v=mobile-save-3';
import {VectorAssets,DrawingCanvas,ArtworkPainter,fullFocus,FILL_GRADIENTS} from './renderer.js?v=tracing-hints-5';
import {collectionPage,stickerImages} from './collection.js?v=wide-border-4';
import {mountThemeCarousel} from './theme-carousel.js?v=sound-1';
import {AudioService} from './audio.js?v=opening-voice-22';
import {CAT_ACTION_DURATION} from './cat-motion.js';
import {homeMotionStyle} from './home-motion.js';
import {PromptVoice} from './prompt-voice.js?v=mobile-fallback-5';
import {DrawingVoice} from './drawing-voice.js';
import {turnBookPage} from './book-turn.js';
const stage=document.querySelector('#stage'),dialogs=document.querySelector('#dialog-root'),saveStatus=document.querySelector('#save-status');
const colors=['#0065fb','#00b8ea','#83ffda','#00e4e8','#b2ff29','#76c900','#a06400','#ff5d00','#ff9b00','#ffe300','#ffff00','#90604d','#ff0085','#483455','#ff74cd','#b300d8','#ff4949','#b92342','#ffb7cc','#ffd3ad','#fff1b8','#c9f2a1','#21a66b','#007d75','#b5e8ff','#668de5','#283c8f','#c6b4f5','#8652b8','#d6b18a','#ffffff','#333344'];
const toolNames=['贴纸','铅笔','蜡笔','油漆桶','刷子','橡皮擦'];
const state={page:'loading',art:null,works:[],theme:0,locked:false,pointer:false,renderer:null,course:null,courses:[],assets:null,store:null,epoch:0,toolScroll:0,materialScroll:{},fresh:null};
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
const audio=new AudioService();
const promptVoice=new PromptVoice(audio);
const collectionVoice=new PromptVoice(audio,new URL('../声音/收集册欢迎-激活版-云夏.mp3',import.meta.url));
collectionVoice.player.defaultPlaybackRate=1.15;
collectionVoice.player.playbackRate=1.15;
collectionVoice.player.preservesPitch=true;
function syncCollectionSpeaker(event){
  const bird=stage.querySelector('.collection-mascot');if(!bird)return;
  const speaking=event?.type!=='waiting'&&collectionVoice.playing;
  const src=`assets/collection-mascot-${speaking?'speaking':'idle'}.svg`;
  if(bird.getAttribute('src')!==src)bird.src=src;
}
for(const event of ['playing','pause','ended','error','waiting'])collectionVoice.player.addEventListener(event,syncCollectionSpeaker);
collectionVoice.onstatechange=()=>syncCollectionSpeaker();
document.addEventListener('visibilitychange',()=>{if(document.hidden)collectionVoice.stop();else if(state.page==='collection'&&!dialogs.children.length)collectionVoice.speak({repeatGap:5000});});
const drawingVoice=new DrawingVoice(audio);
document.addEventListener('visibilitychange',()=>{if(document.hidden)drawingVoice.stop();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)promptVoice.stop();});
mountViewport();
const unlockAudio=()=>{audio.startMusic();audio.unlockEffects(state.page==='home'?THEME_IDS[state.theme]:state.art?.course.themeID??THEME_IDS[state.theme]);};
for(const event of ['pointerdown','pointerup','click'])document.addEventListener(event,unlockAudio,{capture:true,passive:true});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)audio.startMusic();});
window.addEventListener('pageshow',()=>audio.startMusic());
document.addEventListener('click',event=>{
  const target=event.target.closest('button');
  if(target&&!target.matches('.theme-tab,.course-card,.tool,.material,.page-arrow,.pending-sticker'))audio.play('tap');
});
let toastTimer;
function toast(message){const e=document.querySelector('#toast');e.textContent=message;e.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('visible'),2600);}
function button(label,icon,cls='round-button'){return `<button class="${cls}" aria-label="${label}">${icon}</button>`;}
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function mountHomeMotion(){
  let stopped=false,active=null,bag=[],bagTheme=-1,last=null,guideHand=null;const timers=new Set();
  const hideGuide=()=>{guideHand?.remove();guideHand=null;};
  const showGuide=card=>{
    hideGuide();
    const screen=stage.querySelector('.home-screen'),bounds=card.getBoundingClientRect(),area=screen.getBoundingClientRect();
    guideHand=document.createElement('img');guideHand.className='home-tap-guide';guideHand.src='assets/guide-hand.svg';guideHand.alt='';guideHand.setAttribute('aria-hidden','true');
    guideHand.style.left=`${(bounds.left+bounds.width*.55-area.left)/area.width*100}%`;
    guideHand.style.top=`${(bounds.top+bounds.height*.55-area.top)/area.height*100}%`;
    screen.append(guideHand);
  };
  const later=(fn,ms)=>{const timer=setTimeout(()=>{timers.delete(timer);fn();},ms);timers.add(timer);};
  const clear=()=>{hideGuide();for(const timer of timers)clearTimeout(timer);timers.clear();active?.classList.remove('ambient-glow','ambient-performing');active=null;audio.stopRole();};
  const run=()=>{
    if(stopped||state.page!=='home')return;
    if(document.hidden||dialogs.children.length||stage.querySelector('.opening-scene')||reducedMotion.matches){later(run,700);return;}
    if(bagTheme!==state.theme){bag=[];bagTheme=state.theme;}
    if(!bag.length){
      bag=[...stage.querySelectorAll(`#theme-${state.theme} .course-card:not(:disabled)`)];
      for(let i=bag.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[bag[i],bag[j]]=[bag[j],bag[i]];}
      if(bag.length>1&&bag.at(-1)===last)[bag[0],bag[bag.length-1]]=[bag.at(-1),bag[0]];
    }
    const card=bag.pop();if(!card){later(run,1000);return;}active=card;last=card;
    showGuide(card);
    card.classList.add('ambient-glow','ambient-performing');
    const [theme,index]=card.dataset.course.split('_').map(Number),course=state.courses[theme*5+index];
    const role=audio.roleKey(course);if(role)audio.playRole(role,2.6);else audio.play('color');
    later(()=>{hideGuide();card.classList.remove('ambient-glow','ambient-performing');active=null;audio.stopRole();later(run,2200);},2600);
  };
  const restart=()=>{clear();bag=[];later(run,800);};
  const visibility=()=>{if(document.hidden)clear();else restart();};
  const pause=()=>{clear();later(run,1800);};
  const scroll=stage.querySelector('.home-scroll');scroll.addEventListener('scroll',pause,{passive:true});
  stage.addEventListener('pointerdown',pause,{passive:true});
  const observer=new MutationObserver(()=>{if(dialogs.children.length)clear();else restart();});observer.observe(dialogs,{childList:true});
  stage.addEventListener('homethemechange',restart);document.addEventListener('visibilitychange',visibility);later(run,1000);
  return ()=>{stopped=true;clear();observer.disconnect();scroll.removeEventListener('scroll',pause);stage.removeEventListener('pointerdown',pause);stage.removeEventListener('homethemechange',restart);document.removeEventListener('visibilitychange',visibility);};
}
function setCurrentThemeRow(theme){
  audio.unlockEffects(THEME_IDS[theme]);
  for(const row of stage.querySelectorAll('.course-row'))row.classList.toggle('theme-current',Number(row.dataset.theme)===theme);
  stage.dispatchEvent(new Event('homethemechange'));
}
async function enterCourse(card,action){
  if(state.locked||card.dataset.opening)return;
  card.dataset.opening='true';
  audio.play('course');
  card.classList.add('course-opening');
  if(!reducedMotion.matches)await wait(180);
  if(card.isConnected)action();
}
async function stepSuccess(){
  drawingVoice.stop();
  const wrap=stage.querySelector('.canvas-wrap');
  audio.play('step');
  if(!wrap||reducedMotion.matches)return;
  wrap.classList.remove('step-success');
  void wrap.offsetWidth;
  wrap.classList.add('step-success');
  wrap.insertAdjacentHTML('beforeend','<div class="step-celebration" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>');
  await wait(260);
  wrap.querySelector('.step-celebration')?.remove();
  wrap.classList.remove('step-success');
}
function navigate(page){if(page!=='collection')collectionVoice.stop();drawingVoice.stop();promptVoice.stop();audio.stopRole();if(page==='collection'&&!collectionVoice.player.paused)audio.music.volume=audio.musicVolume*.2;state.pageCleanup?.();state.pageCleanup=null;stage.classList.remove('is-dragging-sticker');state.homeCleanup?.();state.homeCleanup=null;state.epoch++;state.renderer?.dispose();state.renderer=null;state.page=page;state.pointer=false;state.locked=false;stage.dataset.page=page;}
function upsert(art){const i=state.works.findIndex(a=>a.id===art.id);if(i<0)state.works.push(structuredClone(art));else if(state.works[i].revision<=art.revision)state.works[i]=structuredClone(art);}
async function persist(art=state.art){if(!art)return;if(!art.completed){saveStatus.textContent='完成后自动保存作品';return;}saveStatus.textContent='正在保存…';await state.store.save(art);upsert(art);saveStatus.textContent='已保存在当前浏览器';}
function showDialog({title,text,voice,primary='再试一次',secondary='留在这里',action}){
  drawingVoice.stop();
  promptVoice.stop();
  dialogs.innerHTML=`<div class="modal-backdrop"><section class="modal simple-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">${voice?'<button class="prompt-replay" aria-label="再听一次语音提示"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 12h5l7-6v20l-7-6H5Z" fill="currentColor"/><path d="M21 11q6 5 0 10m4-14q10 9 0 18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg></button>':''}<div style="font-size:42px;color:#eba5d6" aria-hidden="true">✿</div><h2 id="dialog-title">${title}</h2>${text?`<p>${text}</p>`:''}<div class="dialog-actions"><button class="pill-button secondary" id="dialog-secondary">${secondary}</button><button class="pill-button" id="dialog-primary">${primary}</button></div></section></div>`;
  const oldFocus=document.activeElement;dialogs.querySelector('#dialog-secondary').onclick=()=>{promptVoice.stop();dialogs.innerHTML='';oldFocus?.focus();};dialogs.querySelector('#dialog-primary').onclick=()=>{promptVoice.stop();dialogs.innerHTML='';action();};dialogs.querySelector('#dialog-primary').focus();
  if(voice){dialogs.querySelector('.prompt-replay').onclick=()=>promptVoice.speak(voice);promptVoice.speak(voice);}
}
function saveError(action){
  saveStatus.textContent='尚未保存，请重试';
  if(state.page==='drawing'&&state.art?.completed){
    const wrap=stage.querySelector('.canvas-wrap');
    if(wrap&&!wrap.querySelector('.save-retry')){const retry=document.createElement('button');retry.className='pill-button save-retry';retry.textContent='再试一下';retry.onclick=()=>{retry.remove();action();};wrap.append(retry);}
  }
  showDialog({title:'画作还没存好',text:'小画作仍在这里，点一下再试试。',action:()=>{stage.querySelector('.save-retry')?.remove();action();}});
}
function tabImage(id){
  return `<img class="theme-icon-normal theme-icon-base" src="assets/themes/${id}-base.svg" alt=""><img class="theme-icon-selected theme-icon-base" src="assets/themes/${id}-base-selected.svg" alt=""><img class="theme-icon-art" src="assets/themes/${id}-art.svg" alt="">`;
}
function showHome(){
  navigate('home');
  const completedByCourse=new Map(latestRewards(state.works).map(a=>[a.course.id,a]));
  stage.innerHTML=`<section class="screen home-screen" aria-label="课程首页"><div class="home-scroll">${button('打开设置','<img src="assets/settings.svg" alt="">','home-settings')}${THEMES.map((name,t)=>`<section class="course-row" id="theme-${t}" data-theme="${t}"><h2 class="row-title">${name}</h2><div class="course-cards">${Array.from({length:5},(_,i)=>{
    const course=state.courses[t*5+i],available=!!course,label=course.title;
    let art=`<img src="${course.preview}?v=phone-fit-1" alt="">`;
    const courseID=`${THEME_IDS[t]}_${String(i+1).padStart(2,'0')}`,completed=completedByCourse.get(courseID);
    if(completed?.thumbnail)art=`<img class="completed-preview" src="${completed.thumbnail}" alt="上一次画的${label}">`;
    return `<button class="course-card" style="${homeMotionStyle(THEME_IDS[t],i)}" ${available?'':'disabled'} aria-label="${label}${available?(completed?'，选择重新画或看上次成果':'，开始画画'):'，准备中'}" data-course="${t}_${i}">${art}<span class="course-title">${label}</span>${available?`<span class="play-badge" aria-hidden="true">▶</span>`:'<span class="coming-soon">准备中</span>'}</button>`;
  }).join('')}</div></section>`).join('')}</div>${button('打开奖励收集页','<img src="assets/book-entry.svg" alt="">','book-entry')}<nav class="theme-dock" aria-label="主题分类"><div class="theme-strip" role="tablist">${[6,5,4,3,2,0,1,7,8,9,10].map(i=>`<button class="theme-tab" role="tab" aria-selected="${i===state.theme}" aria-label="${THEMES[i]}" data-theme="${i}">${tabImage(THEME_IDS[i])}<span class="theme-tab-label">${THEMES[i]}</span></button>`).join('')}</div></nav></section>`;
  for(let t=0;t<11;t++)for(let i=0;i<5;i++){
    const card=stage.querySelector(`[data-course="${t}_${i}"]`);
    card.onclick=()=>enterCourse(card,()=>{state.theme=t;state.course=state.courses[t*5+i];const last=completedByCourse.get(state.course.id);if(last)showCourseChoice(last);else startCourse();});
  }
  stage.querySelector('.book-entry').onclick=()=>showCollection();
  stage.querySelector('.home-settings').onclick=()=>{
    const trigger=stage.querySelector('.home-settings');
    const musicPercent=Math.round(audio.musicVolume*100);
    dialogs.innerHTML=`<div class="modal-backdrop"><section class="modal simple-dialog settings-dialog" role="dialog" aria-modal="true" aria-labelledby="settings-title"><h2 id="settings-title">设置</h2><label class="setting-row"><span class="setting-icon" aria-hidden="true">♪</span><span>操作音效</span><input id="settings-sound" type="checkbox" ${audio.enabled?'checked':''}><i aria-hidden="true"></i></label><label class="setting-row"><span class="setting-icon" aria-hidden="true">♫</span><span>背景音乐</span><input id="settings-music" type="checkbox" ${audio.musicEnabled?'checked':''}><i aria-hidden="true"></i></label><label class="music-volume-row"><span>背景音乐音量</span><input id="settings-music-volume" type="range" min="0" max="100" step="1" value="${musicPercent}" ${audio.musicEnabled?'':'disabled'} aria-label="背景音乐音量"><output>${musicPercent}%</output></label><p class="motion-status">${reducedMotion.matches?'已跟随系统减少动态效果':'动效已开启'}</p><div class="dialog-actions"><button class="pill-button secondary" id="settings-close">返回</button></div></section></div>`;
    const settings=dialogs.querySelector('.settings-dialog'),content=document.createElement('div');content.className='settings-content';
    for(const child of [...settings.children])if(!child.matches('h2,.dialog-actions'))content.append(child);
    settings.insertBefore(content,settings.querySelector('.dialog-actions'));
    dialogs.querySelector('#settings-sound').onchange=e=>{audio.setEnabled(e.target.checked);if(e.target.checked)audio.play('theme');else{drawingVoice.stop();promptVoice.stop();}};
    const musicToggle=dialogs.querySelector('#settings-music'),musicVolume=dialogs.querySelector('#settings-music-volume'),musicOutput=dialogs.querySelector('.music-volume-row output');
    musicToggle.onchange=e=>{audio.setMusicEnabled(e.target.checked);musicVolume.disabled=!e.target.checked;};
    musicVolume.oninput=e=>{const value=Number(e.target.value);audio.setMusicVolume(value/100);musicOutput.value=`${value}%`;};
    dialogs.querySelector('#settings-close').onclick=()=>{dialogs.innerHTML='';trigger.focus({preventScroll:true});};
    dialogs.querySelector('#settings-close').focus();
  };
  const scroll=stage.querySelector('.home-scroll'),strip=stage.querySelector('.theme-strip');
  let programUntil=0,scrollFrame;
  const moveCourses=t=>{
    if(t!==state.theme)audio.play('theme');state.theme=t;setCurrentThemeRow(t);programUntil=performance.now()+900;
    scroll.scrollTo({top:t===0?0:stage.querySelector('#theme-'+t).offsetTop-scroll.clientHeight*.23,behavior:'smooth'});
  };
  const carousel=mountThemeCarousel(strip,state.theme,moveCourses);
  scroll.onscroll=()=>{
    cancelAnimationFrame(scrollFrame);
    scrollFrame=requestAnimationFrame(()=>{
      if(performance.now()<programUntil)return;
      let closest=0,best=Infinity;
      for(const row of scroll.querySelectorAll('.course-row')){
        const d=Math.abs(row.offsetTop-scroll.scrollTop-scroll.clientHeight*.23);
        if(d<best){best=d;closest=Number(row.dataset.theme);}
      }
      if(closest!==state.theme){state.theme=closest;setCurrentThemeRow(closest);carousel.select(closest,false);}
    });
  };
  const stopHomeMotion=mountHomeMotion();
  state.homeCleanup=()=>{stopHomeMotion();carousel.dispose();cancelAnimationFrame(scrollFrame);};
  const restoreTheme=state.theme;setCurrentThemeRow(restoreTheme);requestAnimationFrame(()=>{if(strip.isConnected){programUntil=performance.now()+100;scroll.scrollTo({top:restoreTheme===0?0:stage.querySelector('#theme-'+restoreTheme).offsetTop-scroll.clientHeight*.23,behavior:'instant'});}});
}
function showCourseChoice(art){
  navigate('course-choice');
  stage.innerHTML=`<section class="screen course-choice-screen" aria-label="${art.course.title}已完成课程选择"><nav class="choice-nav">${button('回到首页','<img src="assets/nav-home.svg" alt="">')}</nav><button class="course-choice-button redraw-choice" aria-label="重新画${art.course.title}"><img src="assets/replay-draw.svg" alt=""></button><button class="course-choice-button replay-choice" aria-label="播放上一次${art.course.title}作品的动作"><img src="assets/replay-watch.svg" alt=""></button></section>`;
  stage.querySelector('.choice-nav button').onclick=showHome;
  stage.querySelector('.redraw-choice').onclick=()=>{state.course=state.courses.find(c=>c.id===art.course.id);startCourse(true);};
  stage.querySelector('.replay-choice').onclick=()=>showLastResult(art);
}
async function showLastResult(art){
  navigate('last-result');
  stage.innerHTML=`<section class="screen draw-screen" aria-label="上一次${art.course.title}的成果动态"><div class="canvas-wrap"><canvas class="drawing-canvas" role="img" aria-label="上一次${art.course.title}作品自动播放"></canvas></div><nav class="drawing-nav">${button('回到首页','<img src="assets/nav-home.svg" alt="">')}${button('返回重新画或看成果的选择','<img src="assets/nav-prev-active.svg" alt="">')}</nav></section>`;
  const nav=stage.querySelector('.drawing-nav');nav.children[0].onclick=showHome;nav.children[1].onclick=()=>showCourseChoice(art);
  const renderer=new DrawingCanvas(stage.querySelector('canvas'),art,state.assets,{mode:'review'});state.renderer=renderer;
  mountExport(stage.querySelector('.draw-screen'),art);
  const epoch=state.epoch;
  if(audio.roleKey(art.course))audio.playRole(audio.roleKey(art.course),reducedMotion.matches?.6:CAT_ACTION_DURATION);
  await renderer.play();
  if(epoch===state.epoch)audio.stopRole();
}

async function startCourse(restart=false){
  if(state.locked)return;state.locked=true;
  drawingVoice.warm(state.course);
  const drafts=state.works.filter(a=>a.course.id===state.course.id&&!a.completed);
  try{
    for(const draft of drafts)await state.store.remove(draft.id);
    if(drafts.length)state.works=state.works.filter(a=>!drafts.some(d=>d.id===a.id));
    state.art=createArtwork(state.course);
    await persist();showDrawing();
  }catch{state.locked=false;saveError(()=>startCourse(restart));}
}
function navMarkup(reward=false){return `<nav class="drawing-nav" aria-label="绘画导航">${button('回到首页','<img src="assets/nav-home.svg" alt="">')}${reward?'':button('上一个绘画指引步骤','<img src="assets/nav-prev.svg" alt="">')+button('下一个绘画指引步骤','<img src="assets/nav-next.svg" alt="">')}</nav>`;}
function updateNav(){
  if(state.page!=='drawing')return;
  const nav=stage.querySelector('.drawing-nav'),disabled=state.locked||state.pointer;
  nav.children[0].disabled=disabled;nav.children[1].disabled=disabled||state.art.currentIndex===0;nav.children[2].disabled=disabled||!canNext(state.art);
  nav.children[1].querySelector('img').src=`assets/nav-prev${nav.children[1].disabled?'':'-active'}.svg`;nav.children[2].querySelector('img').src=`assets/nav-next${nav.children[2].disabled?'':'-active'}.svg`;
  for(const b of stage.querySelectorAll('.tool-panel button'))b.disabled=disabled;
  if(state.renderer)state.renderer.locked=disabled;
  stage.querySelector('.step-bubbles').innerHTML=state.art.course.steps.map((s,i)=>`<span class="${i===state.art.currentIndex?'current':state.art.drawings[s.id]?.completed?'done':''}"></span>`).join('');
}
function showDrawing(){
  navigate('drawing');stage.innerHTML=`<section class="screen draw-screen" aria-label="绘画页"><div class="canvas-wrap"><canvas class="drawing-canvas" role="img"></canvas><div class="step-bubbles" aria-hidden="true"></div></div><aside class="tool-panel" aria-label="绘画工具与材料"><div class="materials" aria-label="颜色和材料列表"></div><div class="tools" aria-label="工具列表">${TOOLS.map((tool,i)=>`<button class="tool" data-tool="${tool}" aria-label="${toolNames[i]}" aria-pressed="${tool===state.art.tool}"><img src="assets/tool-${tool}.svg" alt=""></button>`).join('')}</div></aside>${navMarkup()}</section>`;
  const canvas=stage.querySelector('canvas');state.renderer=new DrawingCanvas(canvas,state.art,state.assets,{onCommit:commit,onTouch:value=>{state.pointer=value;audio.setDrawing(value&&(state.art.tool==='pencil'||state.art.tool==='crayon'));updateNav();}});state.renderer.refresh();
  const nav=stage.querySelector('.drawing-nav');nav.children[0].onclick=leaveDrawing;nav.children[1].onclick=()=>stepNavigate(false);nav.children[2].onclick=()=>stepNavigate(true);
  const tools=stage.querySelector('.tools');tools.scrollTop=state.toolScroll;tools.onscroll=()=>{state.toolScroll=tools.scrollTop;updateToolNotch();};
  let touchStart=null,dragged=false;
  stage.querySelector('.tool-panel').addEventListener('pointerdown',e=>{touchStart={x:e.clientX,y:e.clientY};dragged=false;});
  stage.querySelector('.tool-panel').addEventListener('pointermove',e=>{if(touchStart&&Math.hypot(e.clientX-touchStart.x,e.clientY-touchStart.y)>8)dragged=true;});
  for(const b of tools.children)b.onclick=()=>{if(state.locked||state.pointer||dragged)return;audio.play('tool');state.materialScroll[state.art.tool]=stage.querySelector('.materials').scrollTop;state.art.toolColors??={};state.art.toolColors[state.art.tool]=state.art.color;state.art.tool=b.dataset.tool;state.art.color=state.art.toolColors[state.art.tool]??(state.art.tool==='crayon'?'#ff0085':state.art.tool==='fillBucket'?fillColors[state.art.fillStyle??1]:state.art.color);state.art.crayonColors=state.art.tool==='crayon'?stripes[state.art.color]??null:null;touch(state.art);renderMaterials();persist().catch(()=>saveError(()=>persist().catch(()=>saveError(()=>persist()))));};
  renderMaterials();updateNav();
  drawingVoice.speak(state.art.course,stepOf(state.art),{intro:true});
  const toolResize=new ResizeObserver(updateToolNotch);toolResize.observe(tools);state.pageCleanup=()=>toolResize.disconnect();
}
function pencilSvg(hex,selected=false){
 const tip=selected?24:102,wood=tip+49;
 return `<svg class="pencil-color" viewBox="0 0 356 102" aria-hidden="true"><path d="M${tip-4} 54L${wood} 96H356V14H${wood}Z" fill="#cfe3e3"/><path d="M${tip} 43L${wood} 0H356V86H${wood}Z" fill="${hex}"/><path d="M${wood} 0H356V29H${wood-32}Z" fill="white" opacity=".15"/><path d="M${wood-32} 57H356V86H${wood}Z" fill="black" opacity=".1"/><path d="M${tip+20} 26L${wood} 0L${wood+14} 15L${wood} 29L${wood+14} 43L${wood} 57L${wood+14} 71L${wood} 86L${tip+20} 60Z" fill="#ffca95"/></svg>`;
}
const fillColors=['#e73ac5','#ff0085','#a26500','#ffffff','#ffbd00','#ed39c8','#ffff00','#00d5f3','#41484a','#ad6414','#ff4949','#ff9b00','#fff1b8','#ffb7cc','#ffd3ad','#83ffda','#21a66b','#00b8ea','#0065fb','#c6b4f5','#8652b8','#333344'];
const waxColors=['#83ffda','#ff0085','#483455','#ffff00','#00c9ef','#b5ff32','#ff74cd','#b300d8','#00ffe4','#0051ff','#a56a0a',...colors.filter(color=>!['#83ffda','#ff0085','#483455','#ffff00','#ff74cd','#b300d8','#0065fb','#a06400'].includes(color))].filter((color,index,array)=>array.indexOf(color)===index);
const stripes={'#ff74cd':['#ff6da5','#ffff00','#83ff71','#59ddff','#c063ff'],'#b300d8':['#bf00ec','#f64ed3','#7b00c0'],'#00ffe4':['#00ebde','#f96eff','#ffff00']};
function crayonSvg(hex,selected=false){
 const tip=selected?24:102,band=tip+73,id='wax'+hex.slice(1),rainbow=stripes[hex];
 return `<svg class="pencil-color crayon-color" viewBox="0 0 356 102" aria-hidden="true"><defs><clipPath id="${id}"><path d="M${tip} 43Q${tip-7} 38 ${tip+3} 32L${band-4} 1Q${band+3} -2 ${band+6} 9H356V87H${band}Z"/></clipPath></defs><path d="M${tip-4} 55L${band} 97H356V16H${band}Z" fill="#cfe3e3"/><path d="M${tip} 43Q${tip-7} 38 ${tip+3} 32L${band-4} 1Q${band+3} -2 ${band+6} 9H356V87H${band}Z" fill="${hex}"/>${rainbow?`<g clip-path="url(#${id})">${Array.from({length:18},(_,i)=>`<path d="M0 ${i*24-180}L356 ${i*24-380}V${i*24-356}L0 ${i*24-156}Z" fill="${rainbow[i%rainbow.length]}"/>`).join('')}</g>`:''}<path d="M${tip+5} 35L${band-10} 12L${band-7} 34Z" fill="white" opacity=".35"/><path d="M${band-3} 4Q${band+9} 43 ${band-3} 87" fill="none" stroke="white" stroke-opacity=".35" stroke-width="10"/><path d="M${band+8} 11H356V25H${band+10}Z" fill="white" opacity=".12"/></svg>`;
}
function updateToolNotch(){const panel=stage.querySelector('.tool-panel'),tools=stage.querySelector('.tools'),selected=tools?.querySelector('[aria-pressed=true]');if(selected){panel.style.setProperty('--notch-top',`${selected.offsetTop-tools.scrollTop}px`);panel.style.setProperty('--notch-height',`${selected.offsetHeight}px`);}}
function renderMaterials(){
  const tool=state.art.tool,panel=stage.querySelector('.materials');panel.dataset.tool=tool;
  for(const b of stage.querySelectorAll('.tool'))b.setAttribute('aria-pressed',String(b.dataset.tool===tool));
  updateToolNotch();
  if(tool==='eraser')panel.innerHTML='<div class="eraser-note"><img src="assets/tool-eraser.svg" alt="">擦掉再画</div>';
  else if(tool==='sticker'||tool==='patternBrush')panel.innerHTML=Array.from({length:8},(_,i)=>`<button class="material round" data-material="${i}" aria-label="${tool==='sticker'?'装饰贴纸':'图案'} ${i+1}" aria-pressed="${i===state.art.materials[tool]}"><img class="material-art" src="assets/${tool==='sticker'?'sticker':'pattern'}-${i}.svg" alt=""></button>`).join('');
  else if(tool==='fillBucket')panel.innerHTML=fillColors.map((hex,i)=>`<button class="material round" data-color="${hex}" data-fill-style="${i}" aria-label="填色材料 ${i+1}" aria-pressed="${i===(state.art.fillStyle??1)}">${FILL_GRADIENTS[i]?`<span class="color-disc" style="background:linear-gradient(135deg,${FILL_GRADIENTS[i].join(',')})" aria-hidden="true"></span>`:i>=10?`<span class="color-disc" style="--color:${hex}" aria-hidden="true"></span>`:`<img class="material-art" src="assets/swatch-${i}.svg" alt="">`}</button>`).join('');
  else panel.innerHTML=(tool==='crayon'?waxColors:colors).map((hex,i)=>`<button class="material ${tool==='fillBucket'?'round':''}" data-color="${hex}" aria-label="颜色 ${hex}" aria-pressed="${hex===state.art.color}">${tool==='fillBucket'?`<span class="color-disc" style="--color:${hex}"></span>`:tool==='crayon'?crayonSvg(hex,hex===state.art.color):pencilSvg(hex,hex===state.art.color)}</button>`).join('');
  panel.scrollTop=state.materialScroll[tool]??0;panel.onscroll=()=>state.materialScroll[tool]=panel.scrollTop;
  let start=null,moved=false;panel.onpointerdown=e=>{start={x:e.clientX,y:e.clientY};moved=false;};panel.onpointermove=e=>{if(start&&Math.hypot(start.x-e.clientX,start.y-e.clientY)>8)moved=true;};
  for(const b of panel.querySelectorAll('button'))b.onclick=()=>{if(state.locked||state.pointer||moved)return;audio.play('color');if(b.dataset.color){state.art.color=b.dataset.color;state.art.toolColors??={};state.art.toolColors[tool]=state.art.color;}if(b.dataset.fillStyle!==undefined)state.art.fillStyle=Number(b.dataset.fillStyle);if(b.dataset.material!==undefined)state.art.materials[tool]=Number(b.dataset.material);touch(state.art);for(const item of panel.querySelectorAll('button'))item.setAttribute('aria-pressed',String(item===b));if(tool==='pencil'||tool==='crayon'){state.art.crayonColors=tool==='crayon'?stripes[state.art.color]??null:null;renderMaterials();}persist().catch(()=>saveError(()=>persist()));};
}
async function commit(mark,cancelled){
  if(state.locked||state.page!=='drawing')return;
  const result=appendMark(state.art,mark,{cancelled});state.renderer.refresh();
  if(result.limit){toast('贴纸已经很多啦，先画一画吧');return;}
  if(!result.accepted){updateNav();return;}
  if(!result.advance&&!cancelled&&['pencil','crayon'].includes(mark.tool)){state.renderer.guideTime=5;state.renderer.dirty=true;}
  if(result.final){state.locked=true;updateNav();await stepSuccess();await saveFinal();return;}
  if(result.advance){state.locked=true;updateNav();const renderer=state.renderer,epoch=state.epoch;persist().catch(()=>saveError(()=>persist()));await stepSuccess();if(epoch!==state.epoch)return;const camera=renderer.animateFocus(stepOf(state.art).focusRect);await camera;await wait(500);if(epoch===state.epoch){state.locked=false;updateNav();drawingVoice.speak(state.art.course,stepOf(state.art));}}
  else {updateNav();persist().catch(()=>saveError(()=>persist()));}
}
async function stepNavigate(forward){
  if(state.locked||state.pointer)return;const changed=forward?next(state.art):previous(state.art);if(!changed)return;
  drawingVoice.stop();state.locked=true;state.renderer.refresh();updateNav();const epoch=state.epoch,promise=state.renderer.animateFocus(stepOf(state.art).focusRect,.65,.1);persist().catch(()=>saveError(()=>persist()));await promise;if(epoch===state.epoch){state.locked=false;updateNav();drawingVoice.speak(state.art.course,stepOf(state.art));}
}
async function leaveDrawing(confirmed=false){
  if(state.pointer||state.locked)return;
  if(confirmed!==true&&Object.values(state.art.drawings).some(d=>d.marks.length)){
    showDialog({title:'重新选素材？',voice:'要重新选择素材吗？点击左边继续画画，点击右边重新选择。',primary:'重新选择',secondary:'继续画画',action:()=>leaveDrawing(true)});return;
  }
  state.locked=true;updateNav();
  try{const id=state.art.id;await state.store.remove(id);state.works=state.works.filter(a=>a.id!==id);state.art=null;showHome();}catch{state.locked=false;updateNav();saveError(()=>leaveDrawing(true));}
}
async function saveFinal(){
  const celebration=audio.playCelebration();
  state.locked=true;updateNav();const wrap=stage.querySelector('.canvas-wrap');if(!wrap.querySelector('.saving-veil'))wrap.insertAdjacentHTML('beforeend','<div class="saving-veil" role="status" aria-label="正在保存作品"><span>✿</span></div>');
  try{state.art.thumbnail=state.renderer.painter.thumbnail(state.art);await persist();}
  catch(error){console.error('保存完成作品失败',error);stage.querySelector('.saving-veil')?.remove();saveError(saveFinal);return;}
  await celebration;await wait(200);
  try{await showReward();}catch(error){console.error('完成展示失败',error);state.art=null;showHome();toast('作品已保存，可以从首页查看');}
}
async function showReward(){
  navigate('reward');stage.innerHTML=`<section class="screen draw-screen" aria-label="完成动画"><div class="canvas-wrap"><canvas class="drawing-canvas" role="img" aria-label="${state.art.course.title}完成动作"></canvas></div>${navMarkup(true)}</section>`;
  stage.querySelector('.drawing-nav button').onclick=()=>{state.art=null;showHome();};
  const epoch=state.epoch,renderer=new DrawingCanvas(stage.querySelector('canvas'),state.art,state.assets,{mode:'reward'});state.renderer=renderer;
  await renderer.animateFocus(fullFocus(state.art.course),.45,0);if(epoch!==state.epoch)return;
  if(audio.roleKey(state.art.course))audio.playRole(audio.roleKey(state.art.course),reducedMotion.matches?.6:CAT_ACTION_DURATION);
  await renderer.play();if(epoch===state.epoch){audio.stopRole();state.fresh=state.art.id;state.theme=THEME_IDS.indexOf(state.art.course.themeID);showCollection();}
}
async function flipCollection(direction){
  const target=state.theme+direction;
  if(state.locked||state.page!=='collection'||target<0||target>=THEMES.length)return;
  state.locked=true;const previous=stage.querySelector('.collection-screen');audio.play('page');state.theme=target;state.fresh=null;
  showCollection();state.locked=true;
  const screen=stage.querySelector('.collection-screen');screen.classList.add('book-turning');
  for(const button of screen.querySelectorAll('button'))button.disabled=true;
  const epoch=state.epoch,turn=turnBookPage(stage,previous,direction,{reduced:reducedMotion.matches}),cleanup=state.pageCleanup;
  state.pageCleanup=()=>{turn.cancel();cleanup?.();};
  await turn.finished;
  if(epoch===state.epoch){screen.classList.remove('book-turning');state.locked=false;
    for(const button of screen.querySelectorAll('.collection-nav button,.pending-sticker,.placed-sticker,.sticker-target'))button.disabled=false;
    screen.querySelector('.prev').disabled=state.theme===0;screen.querySelector('.next').disabled=state.theme===THEMES.length-1;
  }
}
function showCollection(){
  const entering=state.page!=='collection';
  navigate('collection');
  if(entering)collectionVoice.speak({repeatGap:5000});
  const epoch=state.epoch,page=collectionPage(state.works,THEME_IDS[state.theme]),pending=page.find(s=>s.work&&!s.placed),positions=[[1731,706],[1286,314],[1290,724],[1066,529],[1864,370]],pendingIndex=page.indexOf(pending);
  stage.innerHTML=`<section class="screen collection-screen" aria-label="${THEMES[state.theme]}主题奖励收集页"><nav class="collection-nav">${button('回到首页','<img src="assets/nav-home.svg" alt="">')}</nav><aside class="collection-side" aria-label="待贴作品">${pending?`<button class="pending-sticker" aria-label="拖动${pending.work.course.title}贴纸到红色轮廓里" aria-grabbed="false"><img src="${pending.work.thumbnail}" alt="待贴的${pending.work.course.title}"></button>`:''}</aside><div class="sticker-slots">${page.map((slot,i)=>{const [x,y]=positions[i],label=state.courses.find(c=>c.id===slot.courseID)?.title??slot.work?.course.title??`${THEMES[state.theme]} ${i+1}`,isTarget=slot===pending;return `<button class="reward-slot ${slot.placed?'placed-sticker':isTarget?'sticker-target':'unearned-sticker'} ${slot.work?.id===state.fresh?'fresh':''}" ${!slot.placed&&!isTarget?'disabled':''} data-course="${slot.courseID}" aria-label="${slot.placed?`放大查看${label}作品并播放动作`:isTarget?`把${label}贴纸贴在这里`:slot.work?`${label}贴纸等待依次贴入`:`尚未获得${label}贴纸`}" style="left:${x/2532*100}%;top:${y/1170*100}%">${slot.placed?`<img class="sticker-image" src="${slot.work.thumbnail}" alt="孩子画的${label}">`:isTarget?'<img class="drop-outline" alt="红色贴纸位置轮廓">':'<span class="empty-sticker-position" aria-hidden="true">✧</span>'}</button>`;}).join('')}</div>${pending?`<img class="collection-drag-guide" src="assets/guide-hand.svg" alt="" style="--travel-x:${positions[pendingIndex][0]/2532*100-21}cqw;--travel-y:${positions[pendingIndex][1]/2532*100-18*1170/2532}cqw">`:''}${button('上一主题奖励','<img src="assets/collection-prev.svg" alt="">','page-arrow prev')}${button('下一主题奖励','<img src="assets/collection-next.svg" alt="">','page-arrow next')}</section>`;
  stage.querySelector('.collection-nav button').onclick=()=>{if(!state.locked)showHome();};
  const themeID=THEME_IDS[state.theme],collectionScreen=stage.querySelector('.collection-screen');collectionScreen.dataset.collectionTheme=themeID;
  const themeBadge=document.createElement('img');themeBadge.className='collection-theme-badge';themeBadge.src=`assets/themes/${themeID}-art.svg`;themeBadge.alt=`${THEMES[state.theme]}收集册`;collectionScreen.append(themeBadge);
  const prev=stage.querySelector('.page-arrow.prev'),nextButton=stage.querySelector('.page-arrow.next');prev.disabled=state.theme===0;nextButton.disabled=state.theme===10;
  prev.onclick=()=>flipCollection(-1);nextButton.onclick=()=>flipCollection(1);
  const bird=document.createElement('img');bird.className='collection-mascot';bird.alt='收集册小鸟';bird.src='assets/collection-mascot-idle.svg';stage.querySelector('.collection-screen').append(bird);syncCollectionSpeaker();
  for(const slot of page)if(slot.placed)stage.querySelector(`[data-course="${slot.courseID}"]`).onclick=()=>showReview(slot.work);
  for(const slot of page.filter(s=>s.work))stickerImages(slot.work).then(images=>{
    if(state.epoch!==epoch)return;
    const cell=stage.querySelector(`[data-course="${slot.courseID}"]`);
    if(slot.placed)cell.querySelector('img').src=images.sticker;
    if(slot===pending){stage.querySelector('.pending-sticker img').src=images.sticker;cell.querySelector('.drop-outline').src=images.guide;}
  }).catch(error=>console.error('贴纸边框生成失败',error));
  if(pending){
    const source=stage.querySelector('.pending-sticker'),target=stage.querySelector('.sticker-target');
    const place=async()=>{
      if(state.locked||state.epoch!==epoch)return;state.locked=true;source.disabled=true;
      try{const saved=await state.store.collect(pending.work.id);audio.play('sticker');upsert(saved);if(state.epoch!==epoch)return;state.fresh=saved.id;showCollection();}
      catch{if(state.epoch!==epoch)return;state.locked=false;source.disabled=false;toast('贴纸还在这里，再拖一次试试');}
    };
    state.pageCleanup=mountStickerDrag({stage,source,target,onPlace:place});
  }
  state.fresh=null;
}

function mountExport(container,art){
  const save=document.createElement('button');save.className='pill-button artwork-export';save.textContent='保存图片';container.append(save);
  save.onclick=async()=>{
    if(save.disabled)return;save.disabled=true;
    try{
      const image=new ArtworkPainter(state.assets).thumbnail(art),blob=await (await fetch(image)).blob();
      const file=new File([blob],`${art.course.title}.png`,{type:'image/png'});
      if(navigator.canShare?.({files:[file]})){await navigator.share({files:[file],title:art.course.title});}
      else{const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=file.name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('图片已导出，请在下载中查看');}
    }catch(error){if(error.name!=='AbortError'){console.error('导出作品失败',error);toast('图片暂时没导出，请再试一下');}}
    finally{save.disabled=false;}
  };
}
async function showReview(art){
  collectionVoice.stop();
  dialogs.innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-label="${art.course.title}作品回看">${button('关闭作品回看','<svg viewBox="0 0 60 60"><path d="m19 19 22 22m0-22L19 41" class="nav-symbol"/></svg>','round-button modal-close')}<canvas class="drawing-canvas" role="img" aria-label="${art.course.title}作品自动播放"></canvas></section></div>`;
  const renderer=new DrawingCanvas(dialogs.querySelector('canvas'),art,state.assets,{mode:'review'}),close=dialogs.querySelector('button');
  mountExport(dialogs.querySelector('.modal'),art);
  const done=()=>{audio.stopRole();renderer.dispose();dialogs.innerHTML='';document.removeEventListener('keydown',escape);stage.querySelector(`[data-course="${art.course.id}"]`)?.focus();if(state.page==='collection')collectionVoice.speak({repeatGap:5000});};
  const escape=e=>{if(e.key==='Escape')done();};document.addEventListener('keydown',escape);close.onclick=done;close.focus();if(audio.roleKey(art.course))audio.playRole(audio.roleKey(art.course),reducedMotion.matches?.6:CAT_ACTION_DURATION);await renderer.play();if(close.isConnected)audio.stopRole();
}
document.querySelector('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await stage.requestFullscreen();}catch{toast('可以放大浏览器窗口来画画');}};
document.querySelector('.wordmark').onclick=e=>{e.preventDefault();if(state.page==='drawing')leaveDrawing();else if(!state.pointer&&!state.locked){state.art=null;showHome();}};
async function boot(){
  try{
    const [courses,assets,store]=await Promise.all([fetch('./course/catalog.json?v=phone-fit-1').then(r=>{if(!r.ok)throw Error('课程目录加载失败');return r.json();}).then(rows=>Promise.all(rows.map(row=>fetch(`./course/${row.id}.json?v=phone-fit-1`).then(r=>{if(!r.ok)throw Error('课程加载失败');return r.json();}).then(c=>({...validateCourse(c),preview:row.preview}))))),new VectorAssets().load(),new ArtworkStore().open()]);
    state.courses=courses;state.course=courses[0];state.assets=assets;state.store=store;const {valid,invalid}=await store.load();state.works=valid;
    // Rebuild derived thumbnails without changing original artwork or reward count.
    for(const art of state.works)if(art.completed&&!art.thumbnail){art.thumbnail=new ArtworkPainter(assets).thumbnail(art);await store.save(art);}
    showHome();
    await playOpening(stage,{reduced:reducedMotion.matches,audio});
    if(invalid.length)toast('有一份画作暂时打不开，其他作品可以继续使用');
  }catch(error){console.error(error);stage.innerHTML='<div class="loading"><span>✿</span><p>小画笔还没准备好</p><button class="pill-button" id="retry-boot">再试一下</button></div>';stage.querySelector('button').onclick=boot;saveStatus.textContent='请通过本地网址打开，勿直接双击 HTML';}
}
boot();
