import {OPENING_GLYPHS} from './opening-glyphs.js';
// Brand lettering and toy shapes share one short, skippable timeline.
export function openingMarkup(){
  let x=0,index=0;const letters=[];
  for(const glyph of OPENING_GLYPHS){
    if(!glyph.path){x+=glyph.advance;continue;}
    const tilt=[-5,2,-2,3,-4,1,0][index%7];
    letters.push(`<g transform="translate(${x} 0)"><g class="opening-vector-letter" style="--i:${index++}"><g transform="rotate(${tilt} ${glyph.advance/2} 45)"><path class="opening-logo-shadow" d="${glyph.path}"/><path class="opening-logo-outer" d="${glyph.path}"/><path class="opening-logo-inner" d="${glyph.path}"/><path class="opening-logo-depth" d="${glyph.path}"/><path class="opening-logo-face" d="${glyph.path}"/></g></g></g>`);x+=glyph.advance+1;
  }
  return `<span class="opening-capsule" aria-hidden="true"><span class="opening-track"></span><span class="opening-toy opening-heart">♥</span><span class="opening-toy opening-square"></span><span class="opening-toy opening-ball"></span><span class="opening-toy opening-ring"></span><span class="opening-dust"></span></span><svg class="opening-name" viewBox="-30 -30 ${x+60} 170" aria-hidden="true">${letters.join('')}</svg><span class="opening-skip">轻点跳过</span>`;
}

export function playOpening(stage,{reduced=false,audio=null}={}){
  if(reduced||document.hidden)return Promise.resolve();
  return new Promise(resolve=>{
    const opening=document.createElement('button');
    opening.className='opening-scene';opening.type='button';opening.setAttribute('aria-label',"Baby's Drawing，点击跳过开屏动画");
    opening.innerHTML=openingMarkup();stage.append(opening);
    const voice=new Audio(new URL('../声音/开屏品牌英文-超活泼版.mp3',import.meta.url));
    voice.preload='auto';voice.volume=.85;voice.load();
    let finished=false,timer,voiceTimer,blocked=false;
    if(audio){audio.openingActive=true;audio.music.pause();}
    const playVoice=()=>{
      if(finished)return;
      opening.classList.add('opening-voice-hold');
      if(audio?.enabled===false){timer=setTimeout(finish,2100);return;}
      voice.play().then(()=>{blocked=false;opening.dataset.audioState='playing';}).catch(error=>{if(!finished){blocked=true;opening.dataset.audioState=error.name;console.warn('Opening voice playback blocked:',error.name,error.message);}});
    };
    const finish=()=>{if(finished)return;finished=true;clearTimeout(timer);clearTimeout(voiceTimer);voice.onended=null;voice.onerror=null;voice.pause();voice.removeAttribute('src');voice.load();if(audio){audio.openingActive=false;audio.startMusic();}opening.remove();document.removeEventListener('visibilitychange',visibility);document.removeEventListener('keydown',key);resolve();};
    voice.onended=finish;voice.onerror=finish;
    const visibility=()=>{if(document.hidden)finish();};
    const key=e=>{if(e.key==='Escape')finish();};
    opening.onclick=e=>{if(blocked&&!e.target.closest('.opening-skip')){clearTimeout(timer);timer=setTimeout(finish,10000);playVoice();}else finish();};document.addEventListener('visibilitychange',visibility);document.addEventListener('keydown',key);
    voiceTimer=setTimeout(playVoice,1100);
    timer=setTimeout(finish,8000);
  });
}
