import {OPENING_GLYPHS} from './opening-glyphs.js';
// Brand lettering and toy shapes share one short, skippable timeline.
export function openingMarkup(){
  let x=0,index=0;const letters=[];
  for(const glyph of OPENING_GLYPHS){
    if(!glyph.path){x+=glyph.advance;continue;}
    const tilt=[-5,2,-2,3,-4,1,0][index%7];
    letters.push(`<g transform="translate(${x} 0)"><g class="opening-vector-letter" style="--i:${index++}"><g transform="rotate(${tilt} ${glyph.advance/2} 45)"><path class="opening-logo-shadow" d="${glyph.path}"/><path class="opening-logo-outer" d="${glyph.path}"/><path class="opening-logo-inner" d="${glyph.path}"/><path class="opening-logo-depth" d="${glyph.path}"/><path class="opening-logo-face" d="${glyph.path}"/></g></g></g>`);x+=glyph.advance+1;
  }
  return `<span class="opening-capsule" aria-hidden="true"><span class="opening-track"></span><span class="opening-toy opening-heart">♥</span><span class="opening-toy opening-square"></span><span class="opening-toy opening-ball"></span><span class="opening-toy opening-ring"></span><span class="opening-dust"></span></span><svg class="opening-name" viewBox="-30 -30 ${x+60} 170" aria-hidden="true">${letters.join('')}</svg><span class="opening-skip">轻点跳过</span>`;
}

export async function playOpening(stage,{reduced=false,audio=null}={}){
  // Mobile tabs can finish loading before becoming visible. Start the welcome
  // when it can actually be seen, rather than silently skipping it.
  if(document.hidden)await new Promise(resolve=>{
    const visible=()=>{if(!document.hidden){document.removeEventListener('visibilitychange',visible);resolve();}};
    document.addEventListener('visibilitychange',visible);
  });
  return new Promise(resolve=>{
    const opening=document.createElement('button');
    opening.className='opening-scene';opening.type='button';opening.setAttribute('aria-label',"Baby's Drawing，点击跳过开屏动画");
    if(reduced)opening.classList.add('opening-reduced');
    opening.innerHTML=openingMarkup();stage.append(opening);
    const voice=new Audio(new URL('../声音/开屏品牌英文-超活泼版.mp3',import.meta.url));
    voice.preload='auto';voice.volume=.85;voice.load();
    let finished=false,timer,voiceTimer,blocked=false,voiceReady=false;
    if(audio){audio.openingActive=true;audio.music.pause();}
    const playVoice=()=>{
      if(finished)return;
      voiceReady=true;
      opening.classList.add('opening-voice-hold');
      if(audio?.enabled===false){clearTimeout(timer);timer=setTimeout(finish,2100);return;}
      voice.play().then(()=>{blocked=false;opening.dataset.audioState='playing';}).catch(error=>{if(!finished){blocked=true;opening.dataset.audioState=error.name;console.warn('Opening voice playback blocked:',error.name,error.message);}});
    };
    const finish=()=>{if(finished)return;finished=true;clearTimeout(timer);clearTimeout(voiceTimer);voice.onended=null;voice.onerror=null;voice.pause();voice.removeAttribute('src');voice.load();if(audio){audio.openingActive=false;audio.startMusic();}opening.remove();document.removeEventListener('visibilitychange',visibility);document.removeEventListener('keydown',key);resolve();};
    voice.onended=finish;voice.onerror=finish;
    const visibility=()=>{
      if(document.hidden){clearTimeout(timer);clearTimeout(voiceTimer);voice.pause();opening.classList.add('opening-background-paused');}
      else{opening.classList.remove('opening-background-paused');timer=setTimeout(finish,8000);if(voiceReady)playVoice();else voiceTimer=setTimeout(playVoice,reduced?0:1100);}
    };
    const key=e=>{if(e.key==='Escape')finish();};
    opening.onclick=e=>{if(e.target.closest('.opening-skip'))finish();else if(blocked){clearTimeout(timer);timer=setTimeout(finish,10000);playVoice();}};document.addEventListener('visibilitychange',visibility);document.addEventListener('keydown',key);
    voiceTimer=setTimeout(playVoice,reduced?0:1100);
    timer=setTimeout(finish,8000);
  });
}
