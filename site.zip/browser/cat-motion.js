export const CAT_ACTION_DURATION=4.8;
// Pose only: original artwork data and its saved thumbnail are never changed.
export function catPose(time){
  const p=Math.max(0,Math.min(1,time/CAT_ACTION_DURATION));
  const ease=x=>x*x*(3-2*x);
  const weight=ease(Math.min(1,p*12,(1-p)*12));
  return {
    x:Math.sin(p*Math.PI*4)*10*weight,
    y:-Math.abs(Math.sin(p*Math.PI*4))*36*weight,
    body:Math.sin(p*Math.PI*4)*.055*weight,
    head:Math.sin(p*Math.PI*6)*.19*weight,
    tail:Math.sin(p*Math.PI*14)*.58*weight,
    blink:weight>.1&&(time%1.2)>.55&&(time%1.2)<.77,
  };
}
