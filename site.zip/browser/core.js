// Device-independent geometry and drawing state. Uses the same course JSON as iOS.
export const TOOLS=['sticker','pencil','crayon','fillBucket','patternBrush','eraser'];
export const THEME_IDS=['land','ocean','sky','dolls','cars','forest','insects','vegetables','castles','instruments','princesses'];
export const THEMES=['陆地','海洋','天空','娃娃','汽车','森林','昆虫','蔬菜','城堡','乐器','公主'];
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const mix=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});
const sampleCache=new WeakMap(), lineCache=new WeakMap();
export function polylines(path) {
  if(lineCache.has(path)) return lineCache.get(path);
  const lines=[]; let line=[],p={x:0,y:0};
  const flush=()=>{if(line.length)lines.push(line);line=[];};
  function flatten(a,b,c,d,depth=0){
    if(depth>=14 || distance(a,b)+distance(b,c)+distance(c,d)-distance(a,d)<=.15){line.push(d);return;}
    const ab=mix(a,b,.5),bc=mix(b,c,.5),cd=mix(c,d,.5),abc=mix(ab,bc,.5),bcd=mix(bc,cd,.5),mid=mix(abc,bcd,.5);
    flatten(a,ab,abc,mid,depth+1);flatten(mid,bcd,cd,d,depth+1);
  }
  for(const {op,values:v} of path.commands){
    if(op==='M'){flush();p={x:v[0],y:v[1]};line=[p];}
    if(op==='L'){p={x:v[0],y:v[1]};line.push(p);}
    if(op==='Q'){const b={x:v[0],y:v[1]},d={x:v[2],y:v[3]};flatten(p,mix(p,b,2/3),mix(d,b,2/3),d);p=d;}
    if(op==='C'){const d={x:v[4],y:v[5]};flatten(p,{x:v[0],y:v[1]},{x:v[2],y:v[3]},d);p=d;}
    if(op==='Z'&&line.length){line.push(line[0]);p=line[0];}
  }
  flush();lineCache.set(path,lines);return lines;
}
export function samples(path,spacing=1){
  if(spacing===1&&sampleCache.has(path))return sampleCache.get(path);
  const out=[];
  for(const line of polylines(path)){
    out.push(line[0]);let carry=0;
    for(let i=1;i<line.length;i++){
      const a=line[i-1],b=line[i],length=distance(a,b);if(!length)continue;
      let d=spacing-carry;for(;d<=length;d+=spacing)out.push(mix(a,b,d/length));carry=length-(d-spacing);
    }
    out.push(line.at(-1));
  }
  if(spacing===1)sampleCache.set(path,out);return out;
}
export function pathContains(path,p){
  let inside=false;
  for(const line of polylines(path))for(let i=1;i<line.length;i++){
    const a=line[i-1],b=line[i];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside;
  }
  return inside;
}
export function allows(step,p){return step.operationRegions.some(b=>p.x>=b.x&&p.x<=b.x+b.width&&p.y>=b.y&&p.y<=b.y+b.height);}
export function pathString(path){return path.commands.map(c=>`${c.op}${c.values.join(' ')}`).join(' ');}
export function validateCourse(course){
  if(course.schemaVersion!==1||!course.steps?.length||course.width<=0||course.height<=0)throw Error('课程格式不正确');
  const ids=new Set(),targets=new Set();
  for(const step of course.steps){
    if(ids.has(step.id)||!step.operationRegions.length||!step.targets.length||!(step.threshold>0&&step.threshold<=1))throw Error('步骤格式不正确');ids.add(step.id);
    if(step.allowedTools.some(t=>!TOOLS.includes(t)))throw Error('未知工具');
    for(const b of [...step.operationRegions,step.focusRect])if(![b.x,b.y,b.width,b.height].every(Number.isFinite)||b.width<=0||b.height<=0)throw Error('操作区不正确');
    if(step.completionTolerance!==undefined&&(!Number.isFinite(step.completionTolerance)||step.completionTolerance<0))throw Error('描线容差不正确');
    for(const path of [...step.targets.flatMap(t=>[t.path,...(t.guideOutline?[t.guideOutline]:[]),...(t.guideShapes??[])]),step.fillPath]){
      if(path.commands[0]?.op!=='M')throw Error('路径缺少起点');
      for(const c of path.commands)if(!Object.hasOwn({M:2,L:2,Q:4,C:6,Z:0},c.op)||c.values.length!==({M:2,L:2,Q:4,C:6,Z:0}[c.op])||!c.values.every(Number.isFinite))throw Error('路径命令不正确');
    }
    if(step.fillPath.commands.at(-1).op!=='Z')throw Error('填色区未闭合');
    for(const t of step.targets){if(targets.has(t.id)||samples(t.path).length<3||!samples(t.path).every(p=>allows(step,p)))throw Error('目标无效');targets.add(t.id);}
  }
  return course;
}
// Safari on a LAN HTTP origin exposes getRandomValues but not randomUUID.
export function newID(cryptoAPI=globalThis.crypto){
  if(typeof cryptoAPI?.randomUUID==='function')return cryptoAPI.randomUUID();
  const bytes=cryptoAPI.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
  const hex=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
export function createArtwork(course){return {schemaVersion:1,id:newID(),course:structuredClone(course),createdAt:Date.now(),updatedAt:Date.now(),revision:0,currentIndex:0,completed:false,drawings:{},tool:'pencil',color:'#00b8ea',materials:{sticker:1,patternBrush:1}};}
export const stepOf=art=>art.course.steps[art.currentIndex];
export const touch=art=>{art.updatedAt=Date.now();art.revision++;};
export function brushDots(p,tool,width,seed=0){
  const r=width/2;
  if(tool==='crayon')return Array.from({length:11},(_,i)=>{const n=(seed*31+i*71)&1023,a=n*2.399963,d=Math.sqrt(i/11)*r;return {x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d,r:r*.24};});
  return [{...p,r}];
}
const hit=(dot,p)=>Math.hypot(dot.x-p.x,dot.y-p.y)<=dot.r;
// Completion tolerates a child's offset; rendering still uses the untouched dots.
export function targetCovered(step,drawing,p){
  if(!allows(step,p))return false;
  const tolerance=step.completionTolerance??step.defaultWidth*.8;
  for(let i=drawing.marks.length-1;i>=0;i--){
    const mark=drawing.marks[i];if(mark.tool==='fillBucket'||mark.tool==='sticker')continue;
    const extra=mark.tool==='eraser'?0:tolerance;
    if(mark.dots.some(dot=>Math.hypot(dot.x-p.x,dot.y-p.y)<=dot.r+extra))return mark.tool!=='eraser';
  }
  return false;
}
export function coverage(step,drawing){
  return step.targets.map(target=>{const points=samples(target.path);return points.filter(p=>targetCovered(step,drawing,p)).length/points.length;});
}
export function appendMark(art,mark,{cancelled=false}={}){
  if(art.completed)return {accepted:false,advance:false};
  const step=stepOf(art),drawing=art.drawings[step.id]??={marks:[],completed:false};
  if(!step.allowedTools.includes(mark.tool)||!mark.dots.length)return {accepted:false,advance:false};
  const wasCompleted=drawing.completed;
  if(mark.tool==='fillBucket'){
    if(!allows(step,mark.dots[0])||!pathContains(step.fillPath,mark.dots[0]))return {accepted:false,advance:false};
    drawing.marks=drawing.marks.filter(m=>m.tool!=='fillBucket');
  }else if(!mark.dots.some(d=>step.operationRegions.some(b=>d.x+d.r>=b.x&&d.x-d.r<=b.x+b.width&&d.y+d.r>=b.y&&d.y-d.r<=b.y+b.height)))return {accepted:false,advance:false};
  if(mark.tool==='sticker'&&drawing.marks.filter(m=>m.tool==='sticker').length>=20)return {accepted:false,advance:false,limit:true};
  if(mark.tool==='eraser'){
    if(mark.dots.some(d=>allows(step,d)&&pathContains(step.fillPath,d)))drawing.marks=drawing.marks.filter(m=>m.tool!=='fillBucket');
    drawing.marks=drawing.marks.filter(m=>m.tool!=='sticker'||!m.dots.some(a=>mark.dots.some(b=>allows(step,b)&&distance(a,b)<=a.r+b.r)));
  }
  drawing.marks.push(mark);
  const meets=coverage(step,drawing).every(value=>value>=step.threshold);
  drawing.completed=cancelled ? wasCompleted&&meets : meets;
  touch(art);
  // A retained completed part never auto-chains. Only a new completion event advances.
  if(cancelled||wasCompleted||!drawing.completed)return {accepted:true,advance:false};
  if(art.course.steps.every(s=>art.drawings[s.id]?.completed)){art.completed=true;touch(art);return {accepted:true,advance:true,final:true};}
  if(art.currentIndex+1<art.course.steps.length){art.currentIndex++;touch(art);return {accepted:true,advance:true};}
  return {accepted:true,advance:false};
}
export function previous(art){
  if(art.completed||art.currentIndex===0)return false;
  art.currentIndex--;art.drawings[stepOf(art).id]={marks:[],completed:false};touch(art);return true;
}
export function canNext(art){return !art.completed&&art.currentIndex<art.course.steps.length-1&&!!art.drawings[stepOf(art).id]?.completed;}
export function next(art){if(!canNext(art))return false;art.currentIndex++;touch(art);return true;}
export function latestRewards(works){
  const latest=new Map();
  for(const a of works.filter(a=>a.completed)){const old=latest.get(a.course.id);if(!old||a.updatedAt>old.updatedAt||a.updatedAt===old.updatedAt&&a.id>old.id)latest.set(a.course.id,a);}
  return [...latest.values()].sort((a,b)=>a.course.id.localeCompare(b.course.id));
}
export function projection(width,height,focus,top=16){
  const w=Math.max(1,width-32),h=Math.max(1,height-top-16),scale=Math.min(w/focus.width,h/focus.height);
  const x=16+(w-focus.width*scale)/2-focus.x*scale,y=top+(h-focus.height*scale)/2-focus.y*scale;
  return {scale,x,y,toView:p=>({x:p.x*scale+x,y:p.y*scale+y}),toCourse:p=>({x:(p.x-x)/scale,y:(p.y-y)/scale})};
}
