import {catPose,CAT_ACTION_DURATION} from './cat-motion.js';
export function animalPose(animal,time){
 if(!animal||animal==='cat')return catPose(time);
 const p=Math.max(0,Math.min(1,time/CAT_ACTION_DURATION)),w=Math.min(1,p*10,(1-p)*10),s=n=>Math.sin(p*Math.PI*n);
 const pose={x:0,y:0,body:0,head:0,tail:0,leg:0,blink:time%1.4>.8&&time%1.4<1};
 if(animal==='dog'){
  const scratch=p>.48&&p<.88;
  pose.x=scratch?0:s(6)*25*w;pose.y=scratch?0:-Math.abs(s(6))*28*w;pose.head=scratch?-.24*w:s(6)*.12*w;pose.leg=scratch?(.7+Math.sin(time*32)*.3)*w:0;pose.tail=s(16)*.45*w;
 }
 if(animal==='horse'){pose.leg=s(8)*.65*w;pose.y=-Math.abs(s(8))*6*w;pose.head=s(4)*.08*w;pose.tail=s(10)*.25*w;}
 if(animal==='frog'){pose.x=s(4)*40*w;pose.y=-Math.abs(s(6))*55*w;pose.leg=s(6)*.15*w;}
 if(animal==='mouse'){pose.x=s(4)*44*w;pose.y=-Math.abs(s(18))*5*w;pose.body=s(12)*.04*w;pose.head=s(8)*.22*w;pose.tail=s(14)*.3*w;pose.leg=s(20)*.15*w;}
 if(animal==='swim'){pose.x=s(4)*32*w;pose.y=s(6)*9*w;pose.body=s(4)*.08*w;}
 if(animal==='fly'){pose.x=s(4)*26*w;pose.y=s(6)*18*w;pose.body=s(4)*.08*w;}
 if(animal==='float'){pose.x=s(2)*12*w;pose.y=s(4)*19*w;pose.body=s(4)*.035*w;}
 if(animal==='launch'){pose.y=-Math.abs(s(2))*48*w;pose.x=s(8)*5*w;}
 if(animal==='scuttle'){pose.x=s(4)*33*w;pose.y=-Math.abs(s(12))*5*w;pose.body=s(8)*.04*w;}
 if(animal==='drive'){pose.x=s(2)*42*w;pose.y=s(16)*2*w;pose.body=s(4)*.015*w;}
 if(animal==='music'){pose.y=-Math.abs(s(8))*10*w;pose.body=s(8)*.09*w;}
 if(animal==='sway'){pose.y=-Math.abs(s(4))*7*w;pose.body=s(4)*.1*w;}
 if(animal==='bounce'){pose.y=-Math.abs(s(6))*32*w;pose.body=s(6)*.06*w;}
 pose.phase=s(12)*w;
 return pose;
}
