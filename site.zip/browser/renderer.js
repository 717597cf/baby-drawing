import {animalPose} from './animal-motion.js?v=all-themes-1';
import {CAT_ACTION_DURATION} from './cat-motion.js';
import {newID,pathString,stepOf,projection,brushDots,distance,samples,allows,pathContains,targetCovered,coverage} from './core.js';
const ORDER=['tail','body','legs','ears','face','nose','bow'];
const FULL={x:40,y:30,width:320,height:360};
export const FILL_GRADIENTS={4:['#ff729e','#ffb84d','#fff273','#75e8b0','#69cfff','#b18aff'],5:['#ff9bdd','#ec46bb','#a751dc','#713bc2'],6:['#fff991','#ffaddf','#91e9ed'],7:['#9cf1ff','#4bd5ef','#9d8ae9','#d78bef'],8:['#b5c1c3','#72858b','#414f58'],9:['#ffe18a','#e6ad55','#b67436','#864426']};
// Leave headroom for the jump and tilted ears; thumbnails retain their original crop.
export const fullFocus=course=>({...course?.presentation?.fullFocus??{x:20,y:-15,width:360,height:420}});
export class VectorAssets {
  constructor(){this.images=new Map();}
  async load(){
    const names=['cat','land','dog','dolls','princesses','sky','unicorn','guide-hand',...Array.from({length:6},(_,i)=>`fill-texture-${i+4}`),...Array.from({length:8},(_,i)=>`sticker-${i}`),...Array.from({length:8},(_,i)=>`pattern-${i}`)];
    await Promise.all(names.map(async name=>{const image=new Image();image.src=`assets/${name}.svg`;await image.decode();this.images.set(name,image);}));
    return this;
  }
  get(name){return this.images.get(name);}
}
const clipRegion=(c,step)=>{c.beginPath();for(const r of step.operationRegions)c.rect(r.x,r.y,r.width,r.height);c.clip();};
const drawDots=(c,dots)=>{c.beginPath();for(const d of dots){c.moveTo(d.x+d.r,d.y);c.arc(d.x,d.y,d.r,0,Math.PI*2);}c.fill();};
function eye(c,x,y,closed){
  c.fillStyle='#05050a';c.strokeStyle='#05050a';c.lineCap='round';
  if(closed){c.lineWidth=3.8;c.beginPath();c.moveTo(x-15,y);c.quadraticCurveTo(x,y+12,x+15,y);c.stroke();return;}
  c.beginPath();c.arc(x,y,17,0,Math.PI*2);c.fill();
  c.lineWidth=2.5;c.beginPath();for(const d of [-10,0,10]){c.moveTo(x+d,y-12);c.lineTo(x+d*1.25,y-24);}c.stroke();
  c.fillStyle='white';for(const [dx,dy,r] of [[-4,-6,5.5],[7,3,3],[2,11,2]]){c.beginPath();c.arc(x+dx,y+dy,r,0,Math.PI*2);c.fill();}
}
export class ArtworkPainter {
  constructor(assets){this.assets=assets;this.cache=new Map();}
  invalidate(id){for(const [key,canvas] of this.cache)if(!id||key.startsWith(id+':')){canvas.width=0;canvas.height=0;this.cache.delete(key);}}
  layer(art,step,active=null,marksOnly=false){
    const key=art.id+':'+step.id+(marksOnly?':marks':''),marks=art.drawings[step.id]?.marks??[];
    if(!active&&this.cache.has(key))return this.cache.get(key);
    const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=1260;const c=canvas.getContext('2d');c.scale(3,3);clipRegion(c,step);
    let operations=active?[...marks,active]:marks;
    if(active?.tool==='eraser'){
      operations=operations.filter(mark=>mark===active||!(mark.tool==='fillBucket'&&active.dots.some(d=>allows(step,d)&&pathContains(step.fillPath,d)))&&!(mark.tool==='sticker'&&mark.dots.some(a=>active.dots.some(b=>allows(step,b)&&distance(a,b)<=a.r+b.r))));
    }
    if(marksOnly)operations=operations.filter(mark=>['pencil','crayon','patternBrush','sticker','eraser'].includes(mark.tool));
    const fill=operations.findLast(m=>m.tool==='fillBucket'&&m.dots.length);
    if(fill){
      const colors=FILL_GRADIENTS[fill.material];c.fillStyle=fill.color;
      if(colors){const box=step.focusRect,gradient=c.createLinearGradient(box.x,box.y,box.x+box.width,box.y+box.height);colors.forEach((color,i)=>gradient.addColorStop(i/(colors.length-1),color));c.fillStyle=gradient;}
      c.fill(new Path2D(pathString(step.fillPath)),'evenodd');
    }
    for(const mark of operations){
      if(mark.tool==='fillBucket')continue;
      c.globalCompositeOperation=mark.tool==='eraser'?'destination-out':'source-over';c.fillStyle=mark.color;
      if(mark.tool==='sticker'){
        const image=this.assets.get('sticker-'+mark.material);
        for(const d of mark.dots)if(image)c.drawImage(image,d.x-d.r,d.y-d.r,d.r*2,d.r*2);
      }else if(mark.tool==='patternBrush'){
        const image=this.assets.get('pattern-'+mark.material);
        for(const d of mark.dots){c.save();c.beginPath();c.arc(d.x,d.y,d.r,0,Math.PI*2);c.clip();c.fillStyle=mark.color;c.fillRect(d.x-d.r,d.y-d.r,d.r*2,d.r*2);if(image)c.drawImage(image,d.x-d.r,d.y-d.r,d.r*2,d.r*2);c.restore();}
      }else if(mark.tool==='crayon'&&mark.crayonColors){for(let i=0;i<mark.crayonColors.length;i++){c.fillStyle=mark.crayonColors[i];drawDots(c,mark.dots.filter((_,j)=>Math.floor(j/110)%mark.crayonColors.length===i));}}else drawDots(c,mark.dots);
    }
    if(!active)this.cache.set(key,canvas);return canvas;
  }
  draw(c,art,{guide=false,active=null,time=0,animated=false,helper=null,helperSize=77.5}={}){
    const current=stepOf(art);
    let pending=-1;
    if(guide){
      c.save();
      // The operation-area cue stays below paint; the active guide is overlaid later.
      c.lineJoin='round';c.lineCap='round';c.globalAlpha=current.id==='nose'?0:current.id==='bow'?.18:1;c.fillStyle='#ebf6fb';c.strokeStyle='#ebf6fb';c.lineWidth=current.id==='face'?(art.course.presentation?.cueWidth??31):current.id==='body'||current.id==='legs'?50:20;
      const path=new Path2D(pathString(current.fillPath));c.fill(path);c.stroke(path);
      c.fillStyle='white';c.fill(path);c.globalAlpha=1;
      const guideKey=art.id+':'+art.revision+':'+current.id;if(this.guideKey!==guideKey){this.guideKey=guideKey;const progress=coverage(current,art.drawings[current.id]??{marks:[]});this.pendingTarget=current.targets.findIndex((_,i)=>progress[i]<current.threshold);}pending=this.pendingTarget;
      c.restore();
    }
    const pose=animated?animalPose(art.course.animal??art.course.motion,time):null;
    const headTransform=()=>{const [x,y]=art.course.presentation?.headPivot??[200,240];c.translate(x,y);c.rotate(pose.head);c.translate(-x,-y);};
    c.save();
    if(pose){c.translate(200+pose.x,365+pose.y);c.rotate(pose.body);c.translate(-200,-365);}
    for(const id of art.course.presentation?.layerOrder??ORDER){
      const step=art.course.steps.find(s=>s.id===id);if(!step)continue;
      if(!art.drawings[id]?.marks.length&&!(active&&id===current.id))continue;
      c.save();
      if(pose&&(step.parentID==='head'||['face','ears','nose','bow','mane','whiskers'].includes(id)))headTransform();
      const limb=pose&&art.course.presentation?.limbMotion?.stepIDs.includes(id)?art.course.presentation.limbMotion:null;
      if(!limb&&pose&&((art.course.animal==='dog'&&id==='hindleg')||(art.course.animal!=='dog'&&['legs','feet'].includes(id)))&&pose.leg){const pivot=art.course.presentation?.legPivot??(art.course.animal==='dog'?[255,306]:[220,290]);c.translate(...pivot);c.rotate(art.course.animal==='dog'?-pose.leg*1.8:pose.leg);c.translate(-pivot[0],-pivot[1]);}
      if(id==='tail'&&pose){const [x,y]=art.course.presentation?.tailPivot??[293,340];c.translate(x,y);c.rotate(pose.tail);c.translate(-x,-y);}
      const motion=pose&&art.course.presentation?.animatedLayers?.find(m=>m.id===id);if(motion){c.translate(...motion.pivot);c.rotate(pose.phase*motion.amplitude);c.translate(-motion.pivot[0],-motion.pivot[1]);}
      const image=this.layer(art,step,id===current.id?active:null);
      const paint=()=>c.drawImage(image,0,0,art.course.width,art.course.height);
      if(limb&&pose.leg){
        // Move the outer kicking leg together with its body-side stroke. The other
        // three feet stay planted, and the child's original layer is never changed.
        const mask=new Path2D(pathString(limb.mask)),rest=new Path2D();rest.rect(-1000,-1000,2400,2420);rest.addPath(mask);
        c.save();c.clip(rest,'evenodd');paint();c.restore();
        c.save();c.translate(...limb.pivot);c.rotate(Math.max(0,pose.leg)*limb.amplitude);c.translate(-limb.pivot[0],-limb.pivot[1]);c.clip(mask);paint();c.restore();
      }else paint();c.restore();if(active&&id===current.id){image.width=0;image.height=0;}
    }
    const closed=pose?.blink??false;
    c.save();if(pose)headTransform();
    if(art.course.presentation?.eyeStyle==='figma-dot'){
      if(closed){c.strokeStyle='#333';c.lineWidth=4;c.lineCap='round';for(const [x,y,r] of art.course.presentation.eyes){c.beginPath();c.moveTo(x-r,y);c.quadraticCurveTo(x,y+r,x+r,y);c.stroke();}}
      else{c.fillStyle='#333';for(const path of art.course.presentation.eyeShapes??art.course.presentation.eyePaths)c.fill(new Path2D(pathString(path)));}
    }else for(const [x,y,r] of art.course.presentation?.eyes??[[151,184,17],[247,190,17]]){c.save();c.translate(x,y);c.scale(r/17,r/17);eye(c,0,0,closed);c.restore();}
    c.restore();c.restore();
    if(guide&&pending>=0){
      const target=current.targets[pending],p=new Path2D(pathString(target.path));c.save();c.lineJoin='round';c.lineCap='round';
      // Reveal only the untraced portions; existing user marks remain untouched.
      const missingKey=art.id+':'+art.revision+':'+current.id+':'+pending;
      if(this.missingGuideKey!==missingKey){
        this.missingGuideKey=missingKey;this.missingGuide=new Path2D();const guideDrawing=art.drawings[current.id]??{marks:[]};
        const radius=Math.max(current.defaultWidth,art.course.presentation?.guideWidth??0)*.7+4;
        for(const point of samples(target.path,3))if(!targetCovered(current,guideDrawing,point)){this.missingGuide.moveTo(point.x+radius,point.y);this.missingGuide.arc(point.x,point.y,radius,0,Math.PI*2);}
      }
      c.clip(this.missingGuide);
      if(target.guideOutline){
        for(const outline of target.guideShapes??[target.guideOutline]){
          const shape=new Path2D(pathString(outline));c.strokeStyle='rgba(255,255,255,.94)';c.lineWidth=5;c.setLineDash([]);c.stroke(shape);c.fillStyle='#b6b6b6';c.fill(shape);
          c.save();c.clip(shape);c.lineWidth=current.defaultWidth*.65;c.setLineDash(art.course.presentation.dash);c.strokeStyle='#555759';c.stroke(p);c.restore();
        }
      }else{
        const width=current.id==='face'?(art.course.presentation?.guideWidth??current.defaultWidth*.85):({bow:9,legs:10}[current.id]??current.defaultWidth*.85);
        c.lineWidth=width+6;c.strokeStyle='rgba(255,255,255,.94)';c.setLineDash([]);c.stroke(p);
        c.lineWidth=width;c.strokeStyle='#b6b6b6';c.stroke(p);c.setLineDash(current.id==='face'?(art.course.presentation?.dash??[current.defaultWidth*1.5,current.defaultWidth*1.8]):[current.defaultWidth*1.5,current.defaultWidth*1.8]);c.strokeStyle='#555759';c.stroke(p);
      }
      c.restore();
      const marks=this.layer(art,current,active,true);c.drawImage(marks,0,0,art.course.width,art.course.height);
      if(active){marks.width=0;marks.height=0;}
    }
    if(helper){const hand=this.assets.get('guide-hand');if(hand)c.drawImage(hand,helper.x-helperSize*38/310,helper.y-helperSize*36/310,helperSize,helperSize*270/310);}

  }
  thumbnail(art){
    const canvas=document.createElement('canvas');canvas.width=560;canvas.height=560;const c=canvas.getContext('2d'),p=projection(560,560,art.course.presentation?.thumbnailFocus??(art.course.motion?{x:10,y:10,width:380,height:390}:FULL),10);
    c.translate(p.x,p.y);c.scale(p.scale,p.scale);c.fillStyle='white';c.strokeStyle='white';c.lineWidth=10;c.lineJoin='round';for(const step of art.course.steps){const path=new Path2D(pathString(step.fillPath));c.fill(path);c.stroke(path);}this.draw(c,art);
    return canvas.toDataURL('image/png');
  }
}
function referenceProjection(width,height,focus){
 const area=width*2077/2532,scale=Math.min(area/focus.width,height/focus.height),x=(area-focus.width*scale)/2-focus.x*scale,y=(height-focus.height*scale)/2-focus.y*scale;
 return {scale,x,y,toView:p=>({x:p.x*scale+x,y:p.y*scale+y}),toCourse:p=>({x:(p.x-x)/scale,y:(p.y-y)/scale})};
}
export class DrawingCanvas {
  constructor(canvas,art,assets,{mode='drawing',onCommit=()=>{},onTouch=()=>{},onLimit=()=>{}}={}){
    this.canvas=canvas;this.canvas.dataset.mode=mode;this.context=canvas.getContext('2d');this.art=art;this.mode=mode;this.assets=assets;this.painter=new ArtworkPainter(assets);
    this.onCommit=onCommit;this.onTouch=onTouch;this.onLimit=onLimit;this.locked=false;this.active=null;this.pointer=null;this.focus=mode==='drawing'?{...stepOf(art).focusRect}:fullFocus(art.course);this.dirty=true;this.alive=true;this.guideTime=0;this.interacted=!!art.drawings[stepOf(art).id]?.marks.length;this.time=0;
    this.resizeObserver=new ResizeObserver(()=>{if(this.pointer!==null)this.finish(true);this.measure();this.dirty=true;});this.resizeObserver.observe(canvas);
    this.bind();this.measure();this.frame=requestAnimationFrame(t=>this.tick(t));
  }
  measure(){const {width,height}=this.canvas.getBoundingClientRect();this.width=width;this.height=height;const dpr=Math.min(devicePixelRatio||1,2);this.canvas.width=Math.round(width*dpr);this.canvas.height=Math.round(height*dpr);this.dpr=dpr;this.updateProjection();}
  updateProjection(){this.project=this.mode==='drawing'&&this.art.course.presentation?referenceProjection(this.width,this.height,this.focus):projection(this.mode==='drawing'?this.width*2077/2532:this.width,this.height,this.focus,this.mode==='drawing'?Math.max(53,this.height*.16):10);const p=this.project;this.canvas.dataset.scale=p.scale;this.canvas.dataset.offsetX=p.x;this.canvas.dataset.offsetY=p.y;}
  refresh(art=this.art){this.art=art;this.painter.invalidate();this.dirty=true;const step=stepOf(art),progress=coverage(step,art.drawings[step.id]??{marks:[]}),target=step.targets.findIndex((_,i)=>progress[i]<step.threshold),key=step.id+':'+target;if(this.guideTarget!==key){this.guideTime=0;this.interacted=false;this.guideTarget=key;}this.canvas.dataset.target=String(target);this.canvas.dataset.step=step.id;this.canvas.setAttribute('aria-label',`${art.course.title} · ${stepOf(art).title}指引`);}
  helper(){let phase=null;if(!this.interacted&&this.guideTime<1.2)phase=this.guideTime/1.2;else if(this.guideTime>=5&&(this.guideTime-5)%8<1.2)phase=((this.guideTime-5)%8)/1.2;if(phase===null)return null;const step=stepOf(this.art),key=step.id+':'+this.art.revision;if(this.helperKey!==key){const drawing=this.art.drawings[step.id]??{marks:[]};const progress=coverage(step,drawing),target=step.targets.find((_,i)=>progress[i]<step.threshold);this.helperPoints=(target?samples(target.path,2):[]).filter(p=>!targetCovered(step,drawing,p));this.helperKey=key;}const points=this.helperPoints;if(!points.length)return null;return points[Math.min(points.length-1,Math.floor(phase*(points.length-1)))];}
  tick(t){
    if(!this.alive)return;const dt=document.hidden?0:Math.min(this.lastTime?(t-this.lastTime)/1000:0,.06);this.lastTime=t;
    if(this.camera){
      const a=this.camera;a.elapsed+=dt;const f=Math.min(1,Math.max(0,(a.elapsed-a.lead)/a.motion)),v=f*f*(3-2*f);
      for(const key of ['x','y','width','height'])this.focus[key]=a.from[key]+(a.to[key]-a.from[key])*v;
      this.updateProjection();this.dirty=true;
      if(a.elapsed>=a.duration){this.focus={...a.to};this.camera=null;this.guideTime=0;this.interacted=false;this.updateProjection();a.resolve(true);}
    }
    if(this.playback&&!this.camera){
      this.playback.elapsed+=dt;this.time=this.playback.elapsed;this.dirty=true;
      if(this.playback.elapsed>=this.playback.duration){const a=this.playback;this.playback=null;this.time=CAT_ACTION_DURATION;this.canvas.dataset.playback='finished';this.dirty=true;a.resolve(true);}
    }
    if(this.mode==='drawing'&&!this.pointer&&!this.camera){const had=this.helper();this.guideTime+=dt;if(had||this.helper())this.dirty=true;}
    if(this.dirty)this.draw();this.frame=requestAnimationFrame(time=>this.tick(time));
  }
  draw(){
    this.dirty=false;const c=this.context;c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.width,this.height);c.fillStyle='white';c.fillRect(0,0,this.width,this.height);c.save();c.beginPath();c.rect(0,0,this.width,this.height);c.clip();c.translate(this.project.x,this.project.y);c.scale(this.project.scale,this.project.scale);
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.painter.draw(c,this.art,{guide:this.mode==='drawing',active:this.active,time:this.time,animated:this.mode!=='drawing'&&!reduced,helper:this.mode==='drawing'&&!this.pointer&&!this.camera?this.helper():null,helperSize:this.width*.1/this.project.scale});c.restore();
  }
  animateFocus(to,duration=.8,lead=.25){
    if(!this.alive)return Promise.resolve(false);this.camera?.resolve(false);
    if(matchMedia('(prefers-reduced-motion: reduce)').matches){duration=.15;lead=0;}
    this.guideTime=0;this.interacted=!!this.art.drawings[stepOf(this.art).id]?.marks.length;
    return new Promise(resolve=>{this.camera={from:{...this.focus},to:{...to},elapsed:0,duration,lead,motion:Math.max(.05,duration-lead-(duration>.6?.15:0)),resolve};});
  }
  play(){if(!this.alive)return Promise.resolve(false);this.playback?.resolve(false);this.time=0;this.canvas.dataset.playback='playing';return new Promise(resolve=>{this.playback={elapsed:0,duration:matchMedia('(prefers-reduced-motion: reduce)').matches ? .6 : CAT_ACTION_DURATION,resolve};});}
  point(event){const rect=this.canvas.getBoundingClientRect();return this.project.toCourse({x:event.clientX-rect.left,y:event.clientY-rect.top});}
  bind(){
    this.canvas.onpointerdown=event=>{
      if(this.mode!=='drawing'||this.locked||this.camera||this.pointer!==null||event.button!==0||!event.isPrimary)return;
      event.preventDefault();this.pointer=event.pointerId;this.canvas.setPointerCapture(event.pointerId);this.onTouch(true);this.start={x:event.clientX,y:event.clientY};this.lastPoint=null;this.remainder=0;this.seed=0;this.guideTime=0;this.interacted=true;
      const tool=this.art.tool;this.active={id:newID(),tool,color:this.art.color,material:tool==='fillBucket'?(this.art.fillStyle??1):this.art.materials[tool]??0,crayonColors:tool==='crayon'?this.art.crayonColors:null,dots:[]};
      const p=this.point(event),step=stepOf(this.art);
      if(tool==='sticker'){if(allows(step,p))this.active.dots=[{...p,r:18}];}
      else if(tool==='fillBucket'){if(allows(step,p)&&pathContains(step.fillPath,p))this.active.dots=[{...p,r:1}];}
      else this.append(p);this.dirty=true;
    };
    this.canvas.onpointermove=event=>{
      if(event.pointerId!==this.pointer||!this.active)return;
      event.preventDefault();const tool=this.active.tool;
      if(tool==='sticker'||tool==='fillBucket'){if(Math.hypot(event.clientX-this.start.x,event.clientY-this.start.y)>8)this.active.dots=[];}
      else for(const sample of event.getCoalescedEvents?.().length?event.getCoalescedEvents():[event])this.append(this.point(sample));
      this.dirty=true;
    };
    this.canvas.onpointerup=event=>{if(event.pointerId===this.pointer)this.finish(false,event);};
    this.canvas.onpointercancel=event=>{if(event.pointerId===this.pointer)this.finish(true);};
    this.canvas.onlostpointercapture=event=>{if(event.pointerId===this.pointer)this.finish(true);};
    this.visibility=()=>{this.lastTime=null;if(document.hidden&&this.pointer!==null)this.finish(true);};document.addEventListener('visibilitychange',this.visibility);
  }
  append(p){
    const mark=this.active;if(!mark)return;
    const width=mark.tool==='eraser'?18:mark.tool==='patternBrush'?12:stepOf(this.art).defaultWidth*(mark.tool==='crayon'?2.5:1);
    const spacing=mark.tool==='patternBrush'?width*.25:width*.14;
    if(this.lastPoint){const len=distance(this.lastPoint,p);if(len){let d=spacing-this.remainder;for(;d<=len;d+=spacing){mark.dots.push(...brushDots({x:this.lastPoint.x+(p.x-this.lastPoint.x)*d/len,y:this.lastPoint.y+(p.y-this.lastPoint.y)*d/len},mark.tool,width,this.seed++));}this.remainder=len-(d-spacing);}}
    else mark.dots.push(...brushDots(p,mark.tool,width,this.seed++));this.lastPoint=p;
  }
  finish(cancelled,event){
    if(this.pointer===null)return;
    if(event&&this.active&&!['sticker','fillBucket'].includes(this.active.tool))this.append(this.point(event));
    const pointer=this.pointer,mark=this.active;this.pointer=null;this.active=null;this.guideTime=0;this.onTouch(false);this.painter.invalidate();this.dirty=true;
    if(this.canvas.hasPointerCapture(pointer))this.canvas.releasePointerCapture(pointer);
    if(mark?.dots.length)this.onCommit(mark,cancelled);
  }
  dispose(){this.alive=false;this.painter.invalidate();cancelAnimationFrame(this.frame);this.camera?.resolve(false);this.playback?.resolve(false);this.resizeObserver.disconnect();document.removeEventListener('visibilitychange',this.visibility);this.canvas.onpointerdown=this.canvas.onpointermove=this.canvas.onpointerup=this.canvas.onpointercancel=this.canvas.onlostpointercapture=null;}
}
