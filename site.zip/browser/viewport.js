// Fit the complete reference artboard into Safari's visible rectangle, including
// toolbar changes, rather than centring it in the taller layout viewport.
export function fitStage(viewport,insets={},maxWidth=844){
  const number=v=>Number.isFinite(v)?Math.max(0,v):0;
  const width=number(viewport.width),height=number(viewport.height);
  const left=number(insets.left),right=number(insets.right),top=number(insets.top),bottom=number(insets.bottom);
  const availableWidth=Math.max(0,width-left-right),availableHeight=Math.max(0,height-top-bottom);
  const stageWidth=Math.min(availableWidth,availableHeight*844/390,maxWidth);
  return {width:stageWidth,height:stageWidth*390/844,left:left+(availableWidth-stageWidth)/2,top:top+(availableHeight-stageWidth*390/844)/2};
}
export function mountViewport(root=document.querySelector('#app-viewport')){
  if(!root)return ()=>{};
  const style=document.documentElement.style,stage=root.querySelector('#stage'),hint=root.querySelector('.rotate-hint');let frame=0,last='';
  const update=()=>{
    frame=0;const visual=window.visualViewport;
    // Let the browser handle deliberate page zoom without resizing the artboard again.
    if(visual&&Math.abs(visual.scale-1)>.01)return;
    const width=visual?.width||window.innerWidth,height=visual?.height||window.innerHeight,left=visual?.offsetLeft||0,top=visual?.offsetTop||0;
    style.setProperty('--visible-width',width+'px');style.setProperty('--visible-height',height+'px');style.setProperty('--visible-left',left+'px');style.setProperty('--visible-top',top+'px');
    const padding=getComputedStyle(root),insets={left:parseFloat(padding.paddingLeft),right:parseFloat(padding.paddingRight),top:parseFloat(padding.paddingTop),bottom:parseFloat(padding.paddingBottom)},coarse=matchMedia('(pointer:coarse)').matches;
    const fit=fitStage({width,height},insets,coarse?Infinity:844);
    style.setProperty('--stage-width',fit.width+'px');style.setProperty('--stage-height',fit.height+'px');
    root.dataset.orientation=width>=height?'landscape':'portrait';if(hint)hint.hidden=!(coarse&&width<height);
    const bounds=[left,top,width,height,fit.width,fit.height,...Object.values(insets)].join(':');
    if(bounds!==last){last=bounds;stage?.dispatchEvent(new CustomEvent('appviewportchange',{detail:fit}));}
  };
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(update)};
  const events=[[window,'resize'],[window,'orientationchange'],[window,'pageshow'],[window.visualViewport,'resize'],[window.visualViewport,'scroll']].filter(([target])=>target);
  for(const [target,name] of events)target.addEventListener(name,schedule,{passive:true});update();
  return ()=>{cancelAnimationFrame(frame);for(const [target,name] of events)target.removeEventListener(name,schedule)};
}
