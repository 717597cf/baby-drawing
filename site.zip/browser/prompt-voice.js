export class PromptVoice {
  constructor(audio,url=new URL('../声音/重新选择素材-云夏试听.mp3',import.meta.url)){
    this.audio=audio;this.token=0;
    this.player=new Audio(url);
    this.player.preload='auto';this.player.volume=.85;this.player.load();
  }
  stop(){
    clearTimeout(this.repeatTimer);this.repeatTimer=null;
    this.token++;this.player.pause();this.player.currentTime=0;
    this.player.onplaying=null;this.player.onended=null;this.player.onerror=null;
    this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);
  }
  speak({repeatGap=0}={}){
    this.stop();if(!this.audio.enabled)return;
    const token=this.token;
    this.player.onplaying=()=>{if(token===this.token)this.audio.music.volume=this.audio.musicVolume*.2;};
    const finish=()=>{if(token===this.token)this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);};
    this.player.onended=()=>{finish();if(token===this.token&&repeatGap>0&&this.audio.enabled)this.repeatTimer=setTimeout(()=>{if(token===this.token)this.speak({repeatGap});},repeatGap);};this.player.onerror=finish;
    this.player.play().catch(finish);
  }
}
