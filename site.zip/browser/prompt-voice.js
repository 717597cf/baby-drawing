export class PromptVoice {
  constructor(audio,url=new URL('../声音/重新选择素材-云夏试听.mp3',import.meta.url)){
    this.audio=audio;this.token=0;this.url=url;this.source=null;
    this.player=new Audio(url);
    this.player.preload='auto';this.player.volume=.85;this.player.load();
  }
  get playing(){return !!this.source||this.player.paused===false&&!this.player.ended;}
  async playBuffer(token,finish){
    if(typeof this.audio.prepare!=='function')return finish();
    try{
      const context=await this.audio.prepare();
      if(token!==this.token||!this.audio.enabled||!context)return;
      if(!this.bufferPromise)this.bufferPromise=fetch(this.url).then(r=>{if(!r.ok)throw Error(`配音加载失败 ${r.status}`);return r.arrayBuffer();}).then(bytes=>context.decodeAudioData(bytes)).catch(error=>{this.bufferPromise=null;throw error;});
      const buffer=await this.bufferPromise;
      if(token!==this.token||!this.audio.enabled)return;
      if(context.state!=='running')await context.resume();
      if(token!==this.token||!this.audio.enabled)return;
      if(context.state!=='running')throw Error('配音通道尚未解锁');
      const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;
      source.playbackRate.value=this.player.playbackRate||1;gain.gain.value=this.player.volume;
      source.connect(gain).connect(context.destination);this.source=source;
      source.onended=()=>{source.disconnect();gain.disconnect();if(token===this.token){this.source=null;finish();this.onstatechange?.();}};
      source.start();this.audio.music.volume=this.audio.musicVolume*.2;this.onstatechange?.();
    }catch(error){if(token===this.token){console.warn('配音备用通道播放失败',error);finish();}}
  }
  stop(){
    clearTimeout(this.repeatTimer);this.repeatTimer=null;
    this.token++;this.player.pause();this.player.currentTime=0;
    if(this.source){const source=this.source;this.source=null;try{source.stop();}catch{}}
    this.player.onplaying=null;this.player.onended=null;this.player.onerror=null;
    this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);
    this.onstatechange?.();
  }
  speak({repeatGap=0}={}){
    this.stop();if(!this.audio.enabled)return;
    const token=this.token;
    this.player.onplaying=()=>{if(token===this.token)this.audio.music.volume=this.audio.musicVolume*.2;};
    const restore=()=>{if(token===this.token)this.audio.music.volume=this.audio.musicVolume*(this.audio.roleDucking?.35:1);};
    const finish=()=>{restore();if(token===this.token&&repeatGap>0&&this.audio.enabled)this.repeatTimer=setTimeout(()=>{if(token===this.token)this.speak({repeatGap});},repeatGap);};
    this.player.onended=finish;this.player.onerror=restore;
    this.player.play().catch(()=>{if(token===this.token)this.playBuffer(token,finish);});
  }
}
