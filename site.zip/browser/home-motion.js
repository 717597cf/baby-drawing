// Course order is explicit so adding a card cannot silently change another role's action.
const roles={
  land:['tilt','bounce','gallop','jump','peek'],
  ocean:['swim','breathe','dive','squish','sideways'],
  sky:['flutter','glide','float','launch','shimmer'],
  dolls:['wave','breathe','jump','wobble','spin'],
  cars:['drive','rock','rumble','scoop','chug'],
  forest:['jump','peek','tilt','rock','curl'],
  insects:['flutter','hover','crawl','glide','squish'],
  vegetables:['peek','bounce','wobble','breathe','tilt'],
  castles:['rise','bounce','spin','rock','float'],
  instruments:['strum','keys','rumble','squish','wave'],
  princesses:['wave','spin','swim','shimmer','flutter']
};
export function homeMotionStyle(theme,index){
  const action=roles[theme]?.[index]??'float';
  return `--role-motion:role-${action};--role-duration:${(3.6+index*.37+Object.keys(roles).indexOf(theme)*.09).toFixed(2)}s;--role-delay:-${(index*.63).toFixed(2)}s;--role-distance:${(4+index*.65).toFixed(2)}%;--role-angle:${3+index}deg`;
}
